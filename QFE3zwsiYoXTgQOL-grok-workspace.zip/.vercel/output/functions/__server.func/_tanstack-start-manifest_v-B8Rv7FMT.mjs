//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-B8Rv7FMT.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/awards",
			"/competitions",
			"/leadership",
			"/participate",
			"/press",
			"/resources",
			"/committees/$slug",
			"/committees/"
		],
		preloads: ["/assets/index-N2XxDb3h.js", "/assets/react-OrosJ8bI.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-N2XxDb3h.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-CQuTitpo.js",
			"/assets/reveal-CW4LPhnI.js",
			"/assets/person-card-DJ28XOAB.js",
			"/assets/committee-card-D3rjb2Gc.js"
		]
	},
	"/about": {
		filePath: "/workspace/src/routes/about.tsx",
		children: void 0,
		preloads: [
			"/assets/about-4bFWtpJ8.js",
			"/assets/page-hero-e-UydFtb.js",
			"/assets/reveal-CW4LPhnI.js"
		]
	},
	"/awards": {
		filePath: "/workspace/src/routes/awards.tsx",
		children: void 0,
		preloads: ["/assets/awards-DAjl2q3C.js", "/assets/page-hero-e-UydFtb.js"]
	},
	"/competitions": {
		filePath: "/workspace/src/routes/competitions.tsx",
		children: void 0,
		preloads: ["/assets/competitions-kpHuUj5R.js", "/assets/page-hero-e-UydFtb.js"]
	},
	"/leadership": {
		filePath: "/workspace/src/routes/leadership.tsx",
		children: void 0,
		preloads: [
			"/assets/leadership-BhsnAxWw.js",
			"/assets/page-hero-e-UydFtb.js",
			"/assets/person-card-DJ28XOAB.js"
		]
	},
	"/participate": {
		filePath: "/workspace/src/routes/participate.tsx",
		children: void 0,
		preloads: [
			"/assets/participate-CzeJkasO.js",
			"/assets/arrow-up-right-CKsoUkb2.js",
			"/assets/page-hero-e-UydFtb.js"
		]
	},
	"/press": {
		filePath: "/workspace/src/routes/press.tsx",
		children: void 0,
		preloads: [
			"/assets/press-CLYoZKtn.js",
			"/assets/page-hero-e-UydFtb.js",
			"/assets/person-card-DJ28XOAB.js"
		]
	},
	"/resources": {
		filePath: "/workspace/src/routes/resources.tsx",
		children: void 0,
		preloads: [
			"/assets/resources-DOBcRSY-.js",
			"/assets/arrow-up-right-CKsoUkb2.js",
			"/assets/page-hero-e-UydFtb.js"
		]
	},
	"/committees/$slug": {
		filePath: "/workspace/src/routes/committees/$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/_slug-1lbcPska.js",
			"/assets/page-hero-e-UydFtb.js",
			"/assets/person-card-DJ28XOAB.js"
		]
	},
	"/committees/": {
		filePath: "/workspace/src/routes/committees/index.tsx",
		children: void 0,
		preloads: [
			"/assets/committees-DrBgMvaK.js",
			"/assets/page-hero-e-UydFtb.js",
			"/assets/committee-card-D3rjb2Gc.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
