import { t as COMMITTEES } from "./committees-B9-PNPbg.mjs";
import { x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as PageHero } from "./page-hero-Boob4Mvt.mjs";
import { t as CommitteeCard } from "./committee-card-BU4dftiS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/committees-xwmfFCZY.js
var import_jsx_runtime = require_jsx_runtime();
function CommitteesPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
		eyebrow: "Committees",
		title: "Nine committees. Nine global challenges.",
		lede: "Choose your room, read the agenda, and come prepared. Background guides follow committee preference."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "site-container grid gap-5 py-14 sm:grid-cols-2 lg:grid-cols-3 md:py-20",
		children: COMMITTEES.map((committee, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommitteeCard, {
			committee,
			index
		}, committee.slug))
	})] });
}
//#endregion
export { CommitteesPage as component };
