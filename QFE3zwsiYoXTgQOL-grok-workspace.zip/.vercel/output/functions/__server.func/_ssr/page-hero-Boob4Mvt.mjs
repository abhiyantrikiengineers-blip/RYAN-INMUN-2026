import { t as cn } from "./utils-C_uf36nf.mjs";
import { x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/page-hero-Boob4Mvt.js
var import_jsx_runtime = require_jsx_runtime();
function PageHero({ eyebrow, title, lede, meta, children, dense = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: cn("relative overflow-hidden bg-navy text-cream", dense ? "pt-16 pb-14 md:pt-20 md:pb-16" : "pt-16 pb-16 md:pt-20 md:pb-20"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pointer-events-none absolute inset-0 opacity-40",
			"aria-hidden": "true",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -right-24 top-[-20%] h-[28rem] w-[28rem] rounded-full border border-cream/10" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -right-8 top-[8%] h-[18rem] w-[18rem] rounded-full border border-cream/10" })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "site-container relative",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow text-accent-soft",
					children: eyebrow
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "display mt-5 max-w-4xl text-5xl text-cream md:text-6xl lg:text-7xl",
					children: title
				}),
				lede ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "prose-narrow mt-5 text-base text-on-navy-muted md:text-lg",
					children: lede
				}) : null,
				meta ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6 text-sm text-on-navy-muted",
					children: meta
				}) : null,
				children
			]
		})]
	});
}
//#endregion
export { PageHero as t };
