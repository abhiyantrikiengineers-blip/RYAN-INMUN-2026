import { d as SITE_NAME } from "./conference-DkR9jBTp.mjs";
import { n as SECRETARY_GENERAL, r as WORLD_PRESS_TEAM, t as EXECUTIVE_BOARD } from "./leadership-C3FxZGVA.mjs";
import { x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as PageHero } from "./page-hero-Boob4Mvt.mjs";
import { t as PersonCard } from "./person-card-BzPeLEXd.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/leadership-qvjqZs48.js
var import_jsx_runtime = require_jsx_runtime();
function LeadershipPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
		eyebrow: "Leadership",
		title: "The board that runs the rooms.",
		lede: `The Secretary-General, committee chairs, and World Press desk of ${SITE_NAME}.`
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "site-container py-16 md:py-20",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "display text-3xl text-navy",
				children: "Secretary-General"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 max-w-md",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonCard, { person: SECRETARY_GENERAL })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "display mt-14 text-3xl text-navy",
				children: "Executive Board"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
				children: EXECUTIVE_BOARD.map((person) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonCard, { person }, person.name + person.role))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "display mt-14 text-3xl text-navy",
				children: "World Press"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
				children: WORLD_PRESS_TEAM.map((person) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonCard, { person }, person.name))
			})
		]
	})] });
}
//#endregion
export { LeadershipPage as component };
