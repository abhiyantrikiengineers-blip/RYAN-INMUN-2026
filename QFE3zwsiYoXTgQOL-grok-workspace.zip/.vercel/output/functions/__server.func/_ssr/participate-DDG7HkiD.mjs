import { i as DATES, m as TRAINING_FORM, n as CONTACTS, o as FORMS, r as COUNTRY_MATRIX, t as CONFERENCE } from "./conference-DkR9jBTp.mjs";
import { x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as ArrowUpRight } from "../_libs/lucide-react.mjs";
import { r as Button } from "./router-DCuuzYYV.mjs";
import { t as PageHero } from "./page-hero-Boob4Mvt.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/participate-DDG7HkiD.js
var import_jsx_runtime = require_jsx_runtime();
function ParticipatePage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
			eyebrow: "Participate",
			title: "Everything a school needs to arrive prepared.",
			lede: "Fees, deadlines, forms, country allocation, dress code, and position papers for Ryan INMUN 2026."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "site-container grid gap-6 py-16 md:grid-cols-2 md:py-20",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "card-surface p-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase tracking-[0.16em] text-muted",
							children: "Delhi-NCR schools"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "display mt-3 text-5xl text-navy",
							children: CONFERENCE.feeNcr
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: "Per delegate. Shared by the Principal."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "card-surface p-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase tracking-[0.16em] text-muted",
							children: "Outstation delegates"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "display mt-3 text-3xl text-navy",
							children: "Conference, travel & stay"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-muted",
							children: "Includes preparation materials, background guide, conference kit, lunch for all 3 days, tea/coffee at the venue, and social events."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "md:col-span-2 text-sm text-muted",
					children: [
						"Registration fee for all participants, including mentor teachers, should be submitted along with the registration form. Pay orders or bank drafts in Indian Rupees should be crossed and made payable to",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
							className: "text-ink",
							children: CONFERENCE.payee
						}),
						"."
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-cream py-16 md:py-20",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "site-container",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "display text-3xl text-navy",
						children: "Important dates"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-prose text-sm text-muted",
						children: "Choose a committee and inform your school MUN coordinator by 15th June. Your coordinator shares the preference with the INMUN team, and you receive the background guide shortly after."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "mt-8 grid gap-3",
						children: DATES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "card-surface grid gap-2 p-5 sm:grid-cols-[9rem_1fr] sm:items-baseline",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm font-semibold text-accent",
								children: item.date
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium text-navy",
								children: item.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: item.detail
							})] })]
						}, item.date))
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "site-container py-16 md:py-20",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "display text-3xl text-navy",
					children: "Registration forms"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8 grid gap-4 md:grid-cols-2",
					children: FORMS.map((form) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: form.href,
						target: "_blank",
						rel: "noopener noreferrer",
						className: "card-surface flex items-start justify-between gap-4 p-6 transition-transform hover:-translate-y-0.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-medium text-navy",
							children: form.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 block text-sm text-muted",
							children: form.hint
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "size-4 shrink-0 text-muted" })]
					}, form.href))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm text-muted",
					children: "Hotel & travel details — two weeks before the conference, Mumbai CO will inform schools about the stay."
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-cream py-16 md:py-20",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "site-container grid gap-10 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "display text-3xl text-navy",
						children: "Country allocation"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: "School MUN coordinators may contact the regional leads directly with questions on country allocations."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-6 grid gap-4",
						children: CONTACTS.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "card-surface p-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs uppercase tracking-[0.14em] text-muted",
									children: c.region
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 font-medium text-navy",
									children: c.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted",
									children: c.role
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									className: "mt-2 inline-block text-sm text-accent hover:underline",
									href: `mailto:${c.email}`,
									children: c.email
								})
							]
						}, c.email))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "outline",
						className: "mt-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: COUNTRY_MATRIX,
							target: "_blank",
							rel: "noopener noreferrer",
							children: "Open country matrix"
						})
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "display text-3xl text-navy",
						children: "Position papers"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: "A position paper outlines your country or character’s stance on the committee topic and the ideas you plan to propose."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-4 list-disc space-y-2 pl-5 text-sm text-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "How does the agenda impact your country? What is your stance?" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "What past actions has your country taken?" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "What key problems must be addressed, and what solutions do you propose?" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Max 2 pages. 12-point font, single-spaced, justified." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Mention committee and country only. Do not include your name or school." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Due 25 August." })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 flex flex-wrap gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: FORMS[3].href,
								target: "_blank",
								rel: "noopener noreferrer",
								children: "Submit position paper"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							variant: "outline",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: TRAINING_FORM,
								target: "_blank",
								rel: "noopener noreferrer",
								children: "Training session"
							})
						})]
					})
				] })]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "site-container py-16 md:py-20",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "display text-3xl text-navy",
				children: "Dress code"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-prose text-muted",
				children: "Western business formals on all three days of the conference. No casual wear. No school uniforms."
			})]
		})
	] });
}
//#endregion
export { ParticipatePage as component };
