//#region node_modules/.nitro/vite/services/ssr/assets/leadership-C3FxZGVA.js
var SECRETARY_GENERAL = {
	name: "Vishrut Mishra",
	role: "Secretary-General",
	school: "RIS Noida"
};
var EXECUTIVE_BOARD = [
	{
		name: "Ruhani Beri",
		role: "Chairperson, ICJ",
		school: "RIS Rohini",
		committeeSlug: "icj"
	},
	{
		name: "Abhiraj Mehsempuri",
		role: "Chairperson, DISEC",
		school: "RIS Patiala",
		committeeSlug: "disec"
	},
	{
		name: "Sara Sharma",
		role: "Chairperson, CD",
		school: "RIS Vasant Kunj",
		committeeSlug: "cd"
	},
	{
		name: "Vansh Nagpal",
		role: "Chairperson, AI IS",
		school: "RIS Mayur Vihar",
		committeeSlug: "ai-impact-summit"
	},
	{
		name: "Pradyun Pandey",
		role: "Chairperson, INC-5",
		school: "RIS Noida",
		committeeSlug: "inc-5"
	},
	{
		name: "Daksh Gupta",
		role: "Chairperson, WEF",
		school: "RIS Mayur Vihar",
		committeeSlug: "wef"
	},
	{
		name: "Aakarsh Sharma",
		role: "Chairperson, G77",
		school: "RIS Rohini",
		committeeSlug: "g77"
	},
	{
		name: "Akshantra Gupta",
		role: "Chairperson, G77",
		school: "RIS Vasant Kunj",
		committeeSlug: "g77"
	},
	{
		name: "Narun Tripathi",
		role: "Chairperson, INTERPOL",
		school: "RIS Greater Noida",
		committeeSlug: "interpol"
	},
	{
		name: "Parth Sehgal",
		role: "Chairperson, INTERPOL",
		school: "RIS Mayur Vihar",
		committeeSlug: "interpol"
	},
	{
		name: "Vidit Jain",
		role: "Chairperson, BRICS",
		school: "RIS Rohini",
		committeeSlug: "brics"
	},
	{
		name: "Vamsi Maheshwari",
		role: "Chairperson, BRICS",
		school: "RIS Greater Noida",
		committeeSlug: "brics"
	}
];
var WORLD_PRESS_TEAM = [
	{
		name: "Bhavya Bhargava",
		role: "Editor-in-Chief",
		school: "RIS Mayur Vihar"
	},
	{
		name: "Chitransh Srivastav",
		role: "Head of Photographers",
		school: "RIS Noida"
	},
	{
		name: "Eesha Arora",
		role: "Head of Caricaturists",
		school: "RIS Mayur Vihar"
	},
	{
		name: "Angel Batra",
		role: "Editor",
		school: "RIS Rohini (H3)"
	},
	{
		name: "Jahnvi Singh",
		role: "Editor",
		school: "RIS Rohini"
	},
	{
		name: "Sonakshi Bhati",
		role: "Editor",
		school: "RIS Greater Noida"
	}
];
function chairsFor(slug) {
	return EXECUTIVE_BOARD.filter((p) => p.committeeSlug === slug);
}
function initials(name) {
	return name.split(" ").filter(Boolean).slice(0, 2).map((part) => part[0]).join("").toUpperCase();
}
//#endregion
export { initials as a, chairsFor as i, SECRETARY_GENERAL as n, WORLD_PRESS_TEAM as r, EXECUTIVE_BOARD as t };
