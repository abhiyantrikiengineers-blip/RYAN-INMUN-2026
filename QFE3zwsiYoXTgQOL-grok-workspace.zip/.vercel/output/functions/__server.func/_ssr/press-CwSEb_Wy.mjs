import { c as PHOTO_ALBUMS, d as SITE_NAME } from "./conference-DkR9jBTp.mjs";
import { r as WORLD_PRESS_TEAM } from "./leadership-C3FxZGVA.mjs";
import { v as Link, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as Button } from "./router-DCuuzYYV.mjs";
import { t as PageHero } from "./page-hero-Boob4Mvt.mjs";
import { t as PersonCard } from "./person-card-BzPeLEXd.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/press-CwSEb_Wy.js
var import_jsx_runtime = require_jsx_runtime();
function PressPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
		eyebrow: "World Press",
		title: "The conference, recorded as it happens.",
		lede: `Journalists, photographers, and caricaturists covering ${SITE_NAME}.`
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "site-container py-16 md:py-20",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "display text-3xl text-navy",
				children: "The desk"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
				children: WORLD_PRESS_TEAM.map((person) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonCard, { person }, person.name))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "display mt-14 text-3xl text-navy",
				children: "Photograph albums"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-6 grid gap-3",
				children: PHOTO_ALBUMS.map((album) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: album.href,
					target: "_blank",
					rel: "noopener noreferrer",
					className: "text-navy underline-offset-4 hover:underline",
					children: album.label
				}) }, album.href))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				className: "mt-8",
				variant: "outline",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/awards",
					children: "World Press awards"
				})
			})
		]
	})] });
}
//#endregion
export { PressPage as component };
