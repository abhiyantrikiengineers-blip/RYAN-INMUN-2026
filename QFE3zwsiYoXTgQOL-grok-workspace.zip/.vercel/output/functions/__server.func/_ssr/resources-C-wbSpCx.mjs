import { c as PHOTO_ALBUMS, d as SITE_NAME, l as RESOURCE_DRIVE, m as TRAINING_FORM, o as FORMS, r as COUNTRY_MATRIX } from "./conference-DkR9jBTp.mjs";
import { v as Link, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as ArrowUpRight } from "../_libs/lucide-react.mjs";
import { t as PageHero } from "./page-hero-Boob4Mvt.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/resources-C-wbSpCx.js
var import_jsx_runtime = require_jsx_runtime();
var LINKS = [
	{
		label: "Country allocation matrix",
		href: COUNTRY_MATRIX,
		hint: "Assigned countries by school."
	},
	{
		label: "Background guides drive",
		href: RESOURCE_DRIVE,
		hint: "Shared preparation materials."
	},
	{
		label: "Training session form",
		href: TRAINING_FORM,
		hint: "Online training for delegates."
	},
	{
		label: "School registration",
		href: FORMS[0].href,
		hint: FORMS[0].hint
	},
	{
		label: "Delegate information",
		href: FORMS[1].href,
		hint: FORMS[1].hint
	},
	{
		label: "Travel plan",
		href: FORMS[2].href,
		hint: FORMS[2].hint
	},
	{
		label: "Position paper upload",
		href: FORMS[3].href,
		hint: FORMS[3].hint
	}
];
function ResourcesPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
		eyebrow: "Resources",
		title: "Guides, forms, and the record of the conference.",
		lede: `Everything a coordinator or delegate needs for ${SITE_NAME} — plus photographs from the three days.`
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "site-container py-16 md:py-20",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "display text-3xl text-navy",
				children: "Delegate materials"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 grid gap-4 md:grid-cols-2",
				children: LINKS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: item.href,
					target: "_blank",
					rel: "noopener noreferrer",
					className: "card-surface flex items-start justify-between gap-4 p-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block font-medium text-navy",
						children: item.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-1 block text-sm text-muted",
						children: item.hint
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "size-4 text-muted" })]
				}, item.href))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "display mt-14 text-3xl text-navy",
				children: "Photographs"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 grid gap-4 md:grid-cols-3",
				children: PHOTO_ALBUMS.map((album) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: album.href,
					target: "_blank",
					rel: "noopener noreferrer",
					className: "card-surface flex items-center justify-between p-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium text-navy",
						children: album.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "size-4 text-muted" })]
				}, album.href))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-8 text-sm text-muted",
				children: [
					"Looking for chairs? See",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/leadership",
						className: "text-navy underline-offset-4 hover:underline",
						children: "leadership"
					}),
					". For World Press, visit the",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/press",
						className: "text-navy underline-offset-4 hover:underline",
						children: "press desk"
					}),
					"."
				]
			})
		]
	})] });
}
//#endregion
export { ResourcesPage as component };
