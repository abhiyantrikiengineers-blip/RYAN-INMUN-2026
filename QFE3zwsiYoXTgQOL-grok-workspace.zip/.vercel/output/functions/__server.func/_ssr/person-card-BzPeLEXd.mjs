import { t as cn } from "./utils-C_uf36nf.mjs";
import { a as initials } from "./leadership-C3FxZGVA.mjs";
import { v as Link, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/person-card-BzPeLEXd.js
var import_jsx_runtime = require_jsx_runtime();
function PersonCard({ person, featured = false }) {
	const body = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("grid size-12 place-items-center rounded-full border text-sm font-semibold tracking-wide", featured ? "border-cream/20 bg-white/5 text-cream" : "border-line bg-paper text-navy"),
		"aria-hidden": "true",
		children: initials(person.name)
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "min-w-0",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: cn("block font-display text-xl leading-tight", featured ? "text-cream" : "text-navy"),
				children: person.name
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: cn("mt-1 block text-sm", featured ? "text-on-navy-muted" : "text-muted"),
				children: person.role
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: cn("mt-1 block text-xs uppercase tracking-[0.14em]", featured ? "text-cream/55" : "text-muted/80"),
				children: person.school
			})
		]
	})] });
	const className = cn("flex items-start gap-4 rounded-2xl border p-5 transition-[transform,box-shadow,border-color] duration-200", featured ? "border-cream/10 bg-white/4 hover:border-cream/25" : "card-surface hover:-translate-y-0.5 hover:shadow-[var(--shadow-lift)]");
	if (person.committeeSlug) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/committees/$slug",
		params: { slug: person.committeeSlug },
		className,
		children: body
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
		className,
		children: body
	});
}
//#endregion
export { PersonCard as t };
