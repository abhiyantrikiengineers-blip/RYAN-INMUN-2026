import { f as SITE_TAGLINE, p as STATS, t as CONFERENCE } from "./conference-DkR9jBTp.mjs";
import { t as COMMITTEES } from "./committees-B9-PNPbg.mjs";
import { n as SECRETARY_GENERAL, t as EXECUTIVE_BOARD } from "./leadership-C3FxZGVA.mjs";
import { v as Link, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as ArrowDown } from "../_libs/lucide-react.mjs";
import { r as Button } from "./router-DCuuzYYV.mjs";
import { t as PersonCard } from "./person-card-BzPeLEXd.mjs";
import { t as Reveal } from "./reveal-DrYYkon_.mjs";
import { t as CommitteeCard } from "./committee-card-BU4dftiS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CWKRL5DJ.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative flex min-h-[92svh] flex-col justify-end overflow-hidden bg-navy pb-16 pt-16 text-cream md:pb-20",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pointer-events-none absolute inset-0",
					"aria-hidden": "true",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -right-32 top-10 h-[34rem] w-[34rem] rounded-full border border-cream/10" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -right-8 top-32 h-[22rem] w-[22rem] rounded-full border border-cream/10" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-navy to-transparent" })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "site-container relative grid gap-10 lg:grid-cols-[1.4fr_0.8fr] lg:items-end",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-[0.72rem] font-semibold uppercase tracking-[0.22em] text-accent-soft",
							children: [
								CONFERENCE.editionLabel,
								" · ",
								SITE_TAGLINE
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "display mt-5 text-[clamp(3.2rem,8vw,7.2rem)] text-cream",
							children: [
								"Ryan",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								"INMUN 2026"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 max-w-xl text-base text-on-navy-muted md:text-lg",
							children: "India’s longest-running Model United Nations. One thousand delegates. Nine committees. Three days of diplomacy in the capital."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 flex flex-wrap gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								variant: "invert",
								size: "lg",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/participate",
									children: "How to participate"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								variant: "ghost",
								size: "lg",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/committees",
									children: "Explore committees"
								})
							})]
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "grid gap-4 border-t border-cream/15 pt-6 text-sm sm:grid-cols-2 lg:border-t-0 lg:border-l lg:pl-8 lg:pt-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-[0.68rem] uppercase tracking-[0.16em] text-on-navy-muted",
								children: "When"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1 font-medium text-cream",
								children: CONFERENCE.dates
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-[0.68rem] uppercase tracking-[0.16em] text-on-navy-muted",
								children: "Where"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1 font-medium text-cream",
								children: CONFERENCE.venue
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-[0.68rem] uppercase tracking-[0.16em] text-on-navy-muted",
								children: "Host"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1 font-medium text-cream",
								children: CONFERENCE.host
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-[0.68rem] uppercase tracking-[0.16em] text-on-navy-muted",
								children: "Summit"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1 font-medium text-cream",
								children: CONFERENCE.theme
							})] })
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "site-container relative mt-12 flex items-center gap-2 text-xs uppercase tracking-[0.18em] text-on-navy-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, { className: "size-3.5" }), "Scroll to explore"]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-b border-line bg-cream",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "site-container grid grid-cols-2 gap-6 py-8 md:grid-cols-5",
				children: STATS.map((stat) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-3xl text-navy md:text-4xl",
					children: stat.value
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs uppercase tracking-[0.16em] text-muted",
					children: stat.label
				})] }, stat.label))
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "py-20 md:py-24",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "site-container grid gap-10 lg:grid-cols-[0.9fr_1.1fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow",
					children: "The conference"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "display mt-4 text-4xl text-navy md:text-5xl",
					children: "Twenty-four editions of preparing India for the world."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
					delay: 80,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "max-w-prose text-muted",
						children: [
							"Established in 2001 by the Ryan International Group, INMUN is India’s longest-running Model United Nations. The 24th edition convenes at ",
							CONFERENCE.venue,
							" from ",
							CONFERENCE.dates,
							". Delegates debate, negotiate, and draft as diplomats — then close at the",
							" ",
							CONFERENCE.summit,
							" under the theme “",
							CONFERENCE.theme,
							"”."
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "outline",
						className: "mt-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/about",
							children: "Read the story"
						})
					})]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-cream py-20 md:py-24",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "site-container",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow",
					children: "Committees"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex flex-wrap items-end justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "display max-w-xl text-4xl text-navy md:text-5xl",
						children: "Nine rooms. Nine global challenges."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "outline",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/committees",
							children: "All committees"
						})
					})]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3",
					children: COMMITTEES.map((committee, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: index * 40,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommitteeCard, {
							committee,
							index
						})
					}, committee.slug))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "py-20 md:py-24",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "site-container",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow",
						children: "Leadership"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "display mt-4 text-4xl text-navy md:text-5xl",
						children: "The Executive Board"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-10 grid gap-5 md:grid-cols-2 lg:grid-cols-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonCard, { person: SECRETARY_GENERAL }), EXECUTIVE_BOARD.slice(0, 5).map((person) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonCard, { person }, person.name + person.role))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "outline",
						className: "mt-8",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/leadership",
							children: "Meet the full board"
						})
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-navy py-20 text-cream md:py-24",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "site-container flex flex-col items-start gap-6 md:flex-row md:items-end md:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow text-accent-soft",
						children: "Participate"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "display mt-4 max-w-xl text-4xl md:text-5xl",
						children: "Prepare well. Debate hard. Lead with purpose."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-4 max-w-lg text-on-navy-muted",
						children: [
							CONFERENCE.dates,
							" · ",
							CONFERENCE.venue
						]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "invert",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/participate",
							children: "Registration & fees"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "ghost",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/awards",
							children: "View the awards"
						})
					})]
				})]
			})
		})
	] });
}
//#endregion
export { Home as component };
