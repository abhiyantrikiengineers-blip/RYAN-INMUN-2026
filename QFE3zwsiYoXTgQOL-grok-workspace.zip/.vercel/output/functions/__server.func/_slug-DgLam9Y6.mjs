import { d as SITE_NAME } from "./_ssr/conference-DkR9jBTp.mjs";
import { v as Link, x as require_jsx_runtime } from "./_libs/@tanstack/react-router+[...].mjs";
import { n as Route, r as Button } from "./_ssr/router-DCuuzYYV.mjs";
import { t as PageHero } from "./_ssr/page-hero-Boob4Mvt.mjs";
import { t as PersonCard } from "./_ssr/person-card-BzPeLEXd.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_slug-DgLam9Y6.js
var import_jsx_runtime = require_jsx_runtime();
function CommitteeDetail() {
	const { committee, chairs } = Route.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
		eyebrow: `${committee.number} · ${committee.acronym}`,
		title: committee.fullName,
		lede: committee.agenda,
		meta: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
			committee.delegates,
			" delegates",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mx-2 opacity-40",
				children: "·"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/committees",
				className: "underline-offset-4 hover:underline",
				children: "All committees"
			})
		] })
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "site-container grid gap-12 py-16 lg:grid-cols-[1.2fr_0.8fr] md:py-20",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "display text-3xl text-navy",
				children: "The agenda"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 max-w-prose text-muted",
				children: committee.summary
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-10 text-sm font-semibold uppercase tracking-[0.16em] text-muted",
				children: "Questions to research"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-4 grid gap-3",
				children: committee.questions.map((q, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "card-surface flex gap-4 p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display text-xl text-accent",
						children: String(i + 1).padStart(2, "0")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm leading-relaxed text-ink",
						children: q
					})]
				}, q))
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "grid gap-4 self-start",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "display text-2xl text-navy",
					children: "Executive Board"
				}),
				chairs.length ? chairs.map((person) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonCard, { person }, person.name)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Chairs listed on the leadership page."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					className: "mt-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/participate",
						children: ["Register for ", SITE_NAME]
					})
				})
			]
		})]
	})] });
}
//#endregion
export { CommitteeDetail as component };
