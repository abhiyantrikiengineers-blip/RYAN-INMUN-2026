import { createFileRoute } from "@tanstack/react-router";
import { ArrowUpRight } from "lucide-react";
import { PageHero } from "@/components/page-hero";
import { Button } from "@/components/ui/button";
import {
  CONFERENCE,
  CONTACTS,
  COUNTRY_MATRIX,
  DATES,
  FORMS,
  SITE_NAME,
  TRAINING_FORM,
} from "@/data/conference";

export const Route = createFileRoute("/participate")({
  head: () => ({
    meta: [
      { title: `Participate · ${SITE_NAME}` },
      {
        name: "description",
        content: `Fees, dates, registration forms, country allocation, and position papers for ${SITE_NAME}.`,
      },
    ],
  }),
  component: ParticipatePage,
});

function ParticipatePage() {
  return (
    <main>
      <PageHero
        eyebrow="Participate"
        title="Everything a school needs to arrive prepared."
        lede="Fees, deadlines, forms, country allocation, dress code, and position papers for RYAN INMUN 2026."
      />

      <section className="site-container grid gap-6 py-16 md:grid-cols-2 md:py-20">
        <article className="card-surface p-8">
          <p className="text-xs uppercase tracking-[0.16em] text-muted">Delhi-NCR schools</p>
          <p className="display mt-3 text-5xl text-navy">{CONFERENCE.feeNcr}</p>
          <p className="mt-2 text-sm text-muted">Per delegate. Shared by the Principal.</p>
        </article>
        <article className="card-surface p-8">
          <p className="text-xs uppercase tracking-[0.16em] text-muted">Outstation delegates</p>
          <p className="display mt-3 text-3xl text-navy">Conference, travel & stay</p>
          <p className="mt-3 text-sm text-muted">
            Includes preparation materials, background guide, conference kit,
            lunch for all 3 days, tea/coffee at the venue, and social events.
          </p>
        </article>
        <p className="md:col-span-2 text-sm text-muted">
          Registration fee for all participants, including mentor teachers,
          should be submitted along with the registration form. Pay orders or
          bank drafts in Indian Rupees should be crossed and made payable to{" "}
          <strong className="text-ink">{CONFERENCE.payee}</strong>.
        </p>
      </section>

      <section className="bg-cream py-16 md:py-20">
        <div className="site-container">
          <h2 className="display text-3xl text-navy">Important dates</h2>
          <p className="mt-3 max-w-prose text-sm text-muted">
            Choose a committee and inform your school MUN coordinator by 15th
            June. Your coordinator shares the preference with the INMUN team,
            and you receive the background guide shortly after.
          </p>
          <ol className="mt-8 grid gap-3">
            {DATES.map((item) => (
              <li key={item.date} className="card-surface grid gap-2 p-5 sm:grid-cols-[9rem_1fr] sm:items-baseline">
                <span className="text-sm font-semibold text-accent">{item.date}</span>
                <div>
                  <p className="font-medium text-navy">{item.title}</p>
                  <p className="text-sm text-muted">{item.detail}</p>
                </div>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section className="site-container py-16 md:py-20">
        <h2 className="display text-3xl text-navy">Registration forms</h2>
        <div className="mt-8 grid gap-4 md:grid-cols-2">
          {FORMS.map((form) => (
            <a
              key={form.href}
              href={form.href}
              target="_blank"
              rel="noopener noreferrer"
              className="card-surface flex items-start justify-between gap-4 p-6 transition-transform hover:-translate-y-0.5"
            >
              <span>
                <span className="block font-medium text-navy">{form.label}</span>
                <span className="mt-1 block text-sm text-muted">{form.hint}</span>
              </span>
              <ArrowUpRight className="size-4 shrink-0 text-muted" />
            </a>
          ))}
        </div>
        <p className="mt-4 text-sm text-muted">
          Hotel & travel details — two weeks before the conference, Mumbai CO
          will inform schools about the stay.
        </p>
      </section>

      <section className="bg-cream py-16 md:py-20">
        <div className="site-container grid gap-10 lg:grid-cols-2">
          <div>
            <h2 className="display text-3xl text-navy">Country allocation</h2>
            <p className="mt-3 text-sm text-muted">
              School MUN coordinators may contact the regional leads directly
              with questions on country allocations.
            </p>
            <ul className="mt-6 grid gap-4">
              {CONTACTS.map((c) => (
                <li key={c.email} className="card-surface p-5">
                  <p className="text-xs uppercase tracking-[0.14em] text-muted">{c.region}</p>
                  <p className="mt-1 font-medium text-navy">{c.name}</p>
                  <p className="text-sm text-muted">{c.role}</p>
                  <a className="mt-2 inline-block text-sm text-accent hover:underline" href={`mailto:${c.email}`}>
                    {c.email}
                  </a>
                </li>
              ))}
            </ul>
            <Button asChild variant="outline" className="mt-6">
              <a href={COUNTRY_MATRIX} target="_blank" rel="noopener noreferrer">
                Open country matrix
              </a>
            </Button>
          </div>
          <div>
            <h2 className="display text-3xl text-navy">Position papers</h2>
            <p className="mt-3 text-sm text-muted">
              A position paper outlines your country or character’s stance on
              the committee topic and the ideas you plan to propose.
            </p>
            <ul className="mt-4 list-disc space-y-2 pl-5 text-sm text-muted">
              <li>How does the agenda impact your country? What is your stance?</li>
              <li>What past actions has your country taken?</li>
              <li>What key problems must be addressed, and what solutions do you propose?</li>
              <li>Max 2 pages. 12-point font, single-spaced, justified.</li>
              <li>Mention committee and country only. Do not include your name or school.</li>
              <li>Due 25 August.</li>
            </ul>
            <div className="mt-6 flex flex-wrap gap-3">
              <Button asChild>
                <a href={FORMS[3].href} target="_blank" rel="noopener noreferrer">
                  Submit position paper
                </a>
              </Button>
              <Button asChild variant="outline">
                <a href={TRAINING_FORM} target="_blank" rel="noopener noreferrer">
                  Training session
                </a>
              </Button>
            </div>
          </div>
        </div>
      </section>

      <section className="site-container py-16 md:py-20">
        <h2 className="display text-3xl text-navy">Dress code</h2>
        <p className="mt-3 max-w-prose text-muted">
          Western business formals on all three days of the conference. No
          casual wear. No school uniforms.
        </p>
      </section>
    </main>
  );
}
