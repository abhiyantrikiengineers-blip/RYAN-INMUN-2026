import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { PageHero } from "@/components/page-hero";
import { PersonCard } from "@/components/person-card";
import { Button } from "@/components/ui/button";
import { getCommittee } from "@/data/committees";
import { SITE_NAME } from "@/data/conference";
import { chairsFor } from "@/data/leadership";

export const Route = createFileRoute("/committees/$slug")({
  loader: ({ params }) => {
    const committee = getCommittee(params.slug);
    if (!committee) throw notFound();
    return { committee, chairs: chairsFor(committee.slug) };
  },
  head: ({ loaderData }) => ({
    meta: [
      {
        title: loaderData
          ? `${loaderData.committee.fullName} · ${SITE_NAME}`
          : SITE_NAME,
      },
      {
        name: "description",
        content: loaderData
          ? `${loaderData.committee.fullName} at ${SITE_NAME}: ${loaderData.committee.agenda}`
          : SITE_NAME,
      },
    ],
  }),
  component: CommitteeDetail,
});

function CommitteeDetail() {
  const { committee, chairs } = Route.useLoaderData();
  return (
    <main>
      <PageHero
        eyebrow={`${committee.number} · ${committee.acronym}`}
        title={committee.fullName}
        lede={committee.agenda}
        meta={
          <span>
            {committee.delegates} delegates
            <span className="mx-2 opacity-40">·</span>
            <Link to="/committees" className="underline-offset-4 hover:underline">
              All committees
            </Link>
          </span>
        }
      />
      <section className="site-container grid gap-12 py-16 lg:grid-cols-[1.2fr_0.8fr] md:py-20">
        <div>
          <h2 className="display text-3xl text-navy">The agenda</h2>
          <p className="mt-4 max-w-prose text-muted">{committee.summary}</p>
          <h3 className="mt-10 text-sm font-semibold uppercase tracking-[0.16em] text-muted">
            Questions to research
          </h3>
          <ol className="mt-4 grid gap-3">
            {committee.questions.map((q, i) => (
              <li key={q} className="card-surface flex gap-4 p-5">
                <span className="font-display text-xl text-accent">
                  {String(i + 1).padStart(2, "0")}
                </span>
                <p className="text-sm leading-relaxed text-ink">{q}</p>
              </li>
            ))}
          </ol>
        </div>
        <aside className="grid gap-4 self-start">
          <h2 className="display text-2xl text-navy">Executive Board</h2>
          {chairs.length ? (
            chairs.map((person) => (
              <PersonCard key={person.name} person={person} />
            ))
          ) : (
            <p className="text-sm text-muted">Chairs listed on the leadership page.</p>
          )}
          <Button asChild className="mt-2">
            <Link to="/participate">Register for {SITE_NAME}</Link>
          </Button>
        </aside>
      </section>
    </main>
  );
}
