import { createFileRoute } from "@tanstack/react-router";
import { CommitteeCard } from "@/components/committee-card";
import { PageHero } from "@/components/page-hero";
import { COMMITTEES } from "@/data/committees";
import { SITE_NAME } from "@/data/conference";

export const Route = createFileRoute("/committees/")({
  head: () => ({
    meta: [
      { title: `Committees · ${SITE_NAME}` },
      {
        name: "description",
        content: `Nine committees of ${SITE_NAME} — agendas, sizes, and research questions.`,
      },
    ],
  }),
  component: CommitteesPage,
});

function CommitteesPage() {
  return (
    <main>
      <PageHero
        eyebrow="Committees"
        title="Nine committees. Nine global challenges."
        lede="Choose your room, read the agenda, and come prepared. Background guides follow committee preference."
      />
      <section className="site-container grid gap-5 py-14 sm:grid-cols-2 lg:grid-cols-3 md:py-20">
        {COMMITTEES.map((committee, index) => (
          <CommitteeCard key={committee.slug} committee={committee} index={index} />
        ))}
      </section>
    </main>
  );
}
