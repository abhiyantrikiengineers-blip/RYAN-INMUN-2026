import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowUpRight } from "lucide-react";
import { PageHero } from "@/components/page-hero";
import {
  COUNTRY_MATRIX,
  FORMS,
  PHOTO_ALBUMS,
  RESOURCE_DRIVE,
  SITE_NAME,
  TRAINING_FORM,
} from "@/data/conference";

export const Route = createFileRoute("/resources")({
  head: () => ({
    meta: [
      { title: `Resources · ${SITE_NAME}` },
      {
        name: "description",
        content: `Delegate handbook, forms, country matrix, training, and photograph albums for ${SITE_NAME}.`,
      },
    ],
  }),
  component: ResourcesPage,
});

const LINKS = [
  { label: "Country allocation matrix", href: COUNTRY_MATRIX, hint: "Assigned countries by school." },
  { label: "Background guides drive", href: RESOURCE_DRIVE, hint: "Shared preparation materials." },
  { label: "Training session form", href: TRAINING_FORM, hint: "Online training for delegates." },
  { label: "School registration", href: FORMS[0].href, hint: FORMS[0].hint },
  { label: "Delegate information", href: FORMS[1].href, hint: FORMS[1].hint },
  { label: "Travel plan", href: FORMS[2].href, hint: FORMS[2].hint },
  { label: "Position paper upload", href: FORMS[3].href, hint: FORMS[3].hint },
];

function ResourcesPage() {
  return (
    <main>
      <PageHero
        eyebrow="Resources"
        title="Guides, forms, and the record of the conference."
        lede={`Everything a coordinator or delegate needs for ${SITE_NAME} — plus photographs from the three days.`}
      />
      <section className="site-container py-16 md:py-20">
        <h2 className="display text-3xl text-navy">Delegate materials</h2>
        <div className="mt-6 grid gap-4 md:grid-cols-2">
          {LINKS.map((item) => (
            <a
              key={item.href}
              href={item.href}
              target="_blank"
              rel="noopener noreferrer"
              className="card-surface flex items-start justify-between gap-4 p-6"
            >
              <span>
                <span className="block font-medium text-navy">{item.label}</span>
                <span className="mt-1 block text-sm text-muted">{item.hint}</span>
              </span>
              <ArrowUpRight className="size-4 text-muted" />
            </a>
          ))}
        </div>
        <h2 className="display mt-14 text-3xl text-navy">Photographs</h2>
        <div className="mt-6 grid gap-4 md:grid-cols-3">
          {PHOTO_ALBUMS.map((album) => (
            <a
              key={album.href}
              href={album.href}
              target="_blank"
              rel="noopener noreferrer"
              className="card-surface flex items-center justify-between p-6"
            >
              <span className="font-medium text-navy">{album.label}</span>
              <ArrowUpRight className="size-4 text-muted" />
            </a>
          ))}
        </div>
        <p className="mt-8 text-sm text-muted">
          Looking for chairs? See{" "}
          <Link to="/leadership" className="text-navy underline-offset-4 hover:underline">
            leadership
          </Link>
          . For World Press, visit the{" "}
          <Link to="/press" className="text-navy underline-offset-4 hover:underline">
            press desk
          </Link>
          .
        </p>
      </section>
    </main>
  );
}
