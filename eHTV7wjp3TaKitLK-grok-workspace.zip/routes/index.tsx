import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowDown } from "lucide-react";
import { CommitteeCard } from "@/components/committee-card";
import { PersonCard } from "@/components/person-card";
import { Reveal } from "@/components/reveal";
import { Button } from "@/components/ui/button";
import { COMMITTEES } from "@/data/committees";
import {
  CONFERENCE,
  SITE_DESCRIPTION,
  SITE_NAME,
  SITE_TAGLINE,
  STATS,
} from "@/data/conference";
import { EXECUTIVE_BOARD, SECRETARY_GENERAL } from "@/data/leadership";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: SITE_NAME },
      { name: "description", content: SITE_DESCRIPTION },
    ],
  }),
  component: Home,
});

function Home() {
  return (
    <main>
      <section className="relative flex min-h-[92svh] flex-col justify-end overflow-hidden bg-navy pb-16 pt-16 text-cream md:pb-20">
        <div className="pointer-events-none absolute inset-0" aria-hidden="true">
          <div className="absolute -right-32 top-10 h-[34rem] w-[34rem] rounded-full border border-cream/10" />
          <div className="absolute -right-8 top-32 h-[22rem] w-[22rem] rounded-full border border-cream/10" />
          <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-navy to-transparent" />
        </div>
        <div className="site-container relative grid gap-10 lg:grid-cols-[1.4fr_0.8fr] lg:items-end">
          <div>
            <p className="text-[0.72rem] font-semibold uppercase tracking-[0.22em] text-accent-soft">
              {CONFERENCE.editionLabel} · {SITE_TAGLINE}
            </p>
            <h1 className="display mt-5 text-[clamp(3.2rem,8vw,7.2rem)] text-cream">
              RYAN
              <br />
              INMUN 2026
            </h1>
            <p className="mt-6 max-w-xl text-base text-on-navy-muted md:text-lg">
              India’s longest-running Model United Nations. One thousand
              delegates. Nine committees. Three days of diplomacy in the
              capital.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button asChild variant="invert" size="lg">
                <Link to="/participate">How to participate</Link>
              </Button>
              <Button asChild variant="ghost" size="lg">
                <Link to="/committees">Explore committees</Link>
              </Button>
            </div>
          </div>
          <dl className="grid gap-4 border-t border-cream/15 pt-6 text-sm sm:grid-cols-2 lg:border-t-0 lg:border-l lg:pl-8 lg:pt-0">
            <div>
              <dt className="text-[0.68rem] uppercase tracking-[0.16em] text-on-navy-muted">
                When
              </dt>
              <dd className="mt-1 font-medium text-cream">{CONFERENCE.dates}</dd>
            </div>
            <div>
              <dt className="text-[0.68rem] uppercase tracking-[0.16em] text-on-navy-muted">
                Where
              </dt>
              <dd className="mt-1 font-medium text-cream">{CONFERENCE.venue}</dd>
            </div>
            <div>
              <dt className="text-[0.68rem] uppercase tracking-[0.16em] text-on-navy-muted">
                Host
              </dt>
              <dd className="mt-1 font-medium text-cream">{CONFERENCE.host}</dd>
            </div>
            <div>
              <dt className="text-[0.68rem] uppercase tracking-[0.16em] text-on-navy-muted">
                Summit
              </dt>
              <dd className="mt-1 font-medium text-cream">{CONFERENCE.theme}</dd>
            </div>
          </dl>
        </div>
        <p className="site-container relative mt-12 flex items-center gap-2 text-xs uppercase tracking-[0.18em] text-on-navy-muted">
          <ArrowDown className="size-3.5" />
          Scroll to explore
        </p>
      </section>

      <section className="border-b border-line bg-cream">
        <div className="site-container grid grid-cols-2 gap-6 py-8 md:grid-cols-5">
          {STATS.map((stat) => (
            <div key={stat.label}>
              <p className="font-display text-3xl text-navy md:text-4xl">{stat.value}</p>
              <p className="mt-1 text-xs uppercase tracking-[0.16em] text-muted">{stat.label}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="py-20 md:py-24">
        <div className="site-container grid gap-10 lg:grid-cols-[0.9fr_1.1fr]">
          <Reveal>
            <p className="eyebrow">The conference</p>
            <h2 className="display mt-4 text-4xl text-navy md:text-5xl">
              Twenty-four editions of preparing India for the world.
            </h2>
          </Reveal>
          <Reveal delay={80}>
            <p className="max-w-prose text-muted">
              Established in 2001 by the Ryan International Group, INMUN is
              India’s longest-running Model United Nations. The 24th edition
              convenes at {CONFERENCE.venue} from {CONFERENCE.dates}. Delegates
              debate, negotiate, and draft as diplomats — then close at the{" "}
              {CONFERENCE.summit} under the theme “{CONFERENCE.theme}”.
            </p>
            <Button asChild variant="outline" className="mt-6">
              <Link to="/about">Read the story</Link>
            </Button>
          </Reveal>
        </div>
      </section>

      <section className="bg-cream py-20 md:py-24">
        <div className="site-container">
          <Reveal>
            <p className="eyebrow">Committees</p>
            <div className="mt-4 flex flex-wrap items-end justify-between gap-4">
              <h2 className="display max-w-xl text-4xl text-navy md:text-5xl">
                Nine rooms. Nine global challenges.
              </h2>
              <Button asChild variant="outline">
                <Link to="/committees">All committees</Link>
              </Button>
            </div>
          </Reveal>
          <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {COMMITTEES.map((committee, index) => (
              <Reveal key={committee.slug} delay={index * 40}>
                <CommitteeCard committee={committee} index={index} />
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 md:py-24">
        <div className="site-container">
          <Reveal>
            <p className="eyebrow">Leadership</p>
            <h2 className="display mt-4 text-4xl text-navy md:text-5xl">
              The Executive Board
            </h2>
          </Reveal>
          <div className="mt-10 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
            <PersonCard person={SECRETARY_GENERAL} />
            {EXECUTIVE_BOARD.slice(0, 5).map((person) => (
              <PersonCard key={person.name + person.role} person={person} />
            ))}
          </div>
          <Button asChild variant="outline" className="mt-8">
            <Link to="/leadership">Meet the full board</Link>
          </Button>
        </div>
      </section>

      <section className="bg-navy py-20 text-cream md:py-24">
        <div className="site-container flex flex-col items-start gap-6 md:flex-row md:items-end md:justify-between">
          <div>
            <p className="eyebrow text-accent-soft">Participate</p>
            <h2 className="display mt-4 max-w-xl text-4xl md:text-5xl">
              Prepare well. Debate hard. Lead with purpose.
            </h2>
            <p className="mt-4 max-w-lg text-on-navy-muted">
              {CONFERENCE.dates} · {CONFERENCE.venue}
            </p>
          </div>
          <div className="flex flex-wrap gap-3">
            <Button asChild variant="invert">
              <Link to="/participate">Registration & fees</Link>
            </Button>
            <Button asChild variant="ghost">
              <Link to="/awards">View the awards</Link>
            </Button>
          </div>
        </div>
      </section>
    </main>
  );
}
