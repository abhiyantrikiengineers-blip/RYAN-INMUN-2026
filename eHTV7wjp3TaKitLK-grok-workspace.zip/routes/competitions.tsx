import { createFileRoute, Link } from "@tanstack/react-router";
import { PageHero } from "@/components/page-hero";
import { Button } from "@/components/ui/button";
import { SITE_NAME } from "@/data/conference";

export const Route = createFileRoute("/competitions")({
  head: () => ({
    meta: [
      { title: `Competitions · ${SITE_NAME}` },
      {
        name: "description",
        content: `My Country 2026 digital news reportage competition at ${SITE_NAME}.`,
      },
    ],
  }),
  component: CompetitionsPage,
});

function CompetitionsPage() {
  return (
    <main>
      <PageHero
        eyebrow="Competitions"
        title="My Country 2026"
        lede="Digital news reportage. Each delegation creates a four-minute self-made news report on the significant developments in their assigned country."
      />
      <section className="site-container grid gap-10 py-16 lg:grid-cols-[1.2fr_0.8fr] md:py-20">
        <div>
          <h2 className="display text-3xl text-navy">The brief</h2>
          <p className="mt-4 max-w-prose text-muted">
            Your video should provide a captivating overview of your country
            and summarise recent events across politics, economy, society,
            technology, law, and environment.
          </p>
          <ul className="mt-6 grid gap-3 text-sm text-muted">
            <li className="card-surface p-5">Length: 4 minutes.</li>
            <li className="card-surface p-5">Upload to YouTube and share the link by 15 August.</li>
            <li className="card-surface p-5">
              Top ten videos are awarded during the closing ceremony of {SITE_NAME}.
            </li>
          </ul>
        </div>
        <aside className="card-surface self-start p-7">
          <p className="text-xs uppercase tracking-[0.16em] text-muted">Also recognised</p>
          <h3 className="display mt-3 text-2xl text-navy">Conference awards</h3>
          <p className="mt-3 text-sm text-muted">
            Best Delegate by committee, Best Delegation, World Press awards,
            and My Country 2026.
          </p>
          <Button asChild className="mt-6" variant="outline">
            <Link to="/awards">See the awards</Link>
          </Button>
        </aside>
      </section>
    </main>
  );
}
