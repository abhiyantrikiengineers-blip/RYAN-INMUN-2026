import { createFileRoute, Link } from "@tanstack/react-router";
import { PageHero } from "@/components/page-hero";
import { Reveal } from "@/components/reveal";
import { Button } from "@/components/ui/button";
import { CONFERENCE, SITE_NAME } from "@/data/conference";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: `About · ${SITE_NAME}` },
      {
        name: "description",
        content: `About ${SITE_NAME}, the 24th Indian Model United Nations hosted by the Ryan International Group of Schools.`,
      },
    ],
  }),
  component: AboutPage,
});

function AboutPage() {
  return (
    <main>
      <PageHero
        eyebrow="About"
        title="India’s longest-running Model United Nations."
        lede={`${SITE_NAME} is the 24th edition of INMUN, established in 2001 by the Ryan International Group. For over two decades it has been the proving ground for young diplomats.`}
      />
      <section className="site-container grid gap-12 py-16 md:grid-cols-[1fr_1fr] md:py-24">
        <Reveal>
          <h2 className="display text-3xl text-navy md:text-4xl">The conference</h2>
          <p className="mt-4 text-muted">
            More than 1,000 student delegates from over 100 schools across 25
            Indian cities and the UAE gather in New Delhi. Over three days they
            take on the roles of diplomats, debating global issues, negotiating
            positions, and working towards resolutions.
          </p>
          <p className="mt-4 text-muted">
            The conference culminates in the {CONFERENCE.summit} at the{" "}
            {CONFERENCE.summitVenue}, held under the theme “{CONFERENCE.theme}”.
          </p>
        </Reveal>
        <Reveal delay={80}>
          <blockquote className="card-surface p-8">
            <p className="font-display text-2xl leading-snug text-navy">
              “The students who represent nations at INMUN today will represent
              India tomorrow. Across twenty-four editions, this conference has
              been their proving ground, and its alumni today serve the nation
              as judges, diplomats, and IAS and IPS officers.”
            </p>
            <footer className="mt-6 text-sm text-muted">
              Dr. Grace Pinto
              <span className="mt-1 block uppercase tracking-[0.14em]">
                Managing Director · Ryan International Group
              </span>
            </footer>
          </blockquote>
        </Reveal>
      </section>
      <section className="bg-cream py-16 md:py-20">
        <div className="site-container">
          <h2 className="display text-3xl text-navy">At a glance</h2>
          <dl className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {[
              ["Edition", CONFERENCE.editionLabel],
              ["Dates", CONFERENCE.dates],
              ["Venue", CONFERENCE.venue],
              ["Host", CONFERENCE.host],
            ].map(([k, v]) => (
              <div key={k}>
                <dt className="text-xs uppercase tracking-[0.16em] text-muted">{k}</dt>
                <dd className="mt-2 font-medium text-navy">{v}</dd>
              </div>
            ))}
          </dl>
          <Button asChild className="mt-10">
            <Link to="/participate">Participate in {SITE_NAME}</Link>
          </Button>
        </div>
      </section>
    </main>
  );
}
