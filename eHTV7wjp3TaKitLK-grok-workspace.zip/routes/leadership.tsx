import { createFileRoute } from "@tanstack/react-router";
import { PageHero } from "@/components/page-hero";
import { PersonCard } from "@/components/person-card";
import { SITE_NAME } from "@/data/conference";
import {
  EXECUTIVE_BOARD,
  SECRETARY_GENERAL,
  WORLD_PRESS_TEAM,
} from "@/data/leadership";

export const Route = createFileRoute("/leadership")({
  head: () => ({
    meta: [
      { title: `Leadership · ${SITE_NAME}` },
      {
        name: "description",
        content: `Secretary-General, Executive Board, and World Press leadership for ${SITE_NAME}.`,
      },
    ],
  }),
  component: LeadershipPage,
});

function LeadershipPage() {
  return (
    <main>
      <PageHero
        eyebrow="Leadership"
        title="The board that runs the rooms."
        lede={`The Secretary-General, committee chairs, and World Press desk of ${SITE_NAME}.`}
      />
      <section className="site-container py-16 md:py-20">
        <h2 className="display text-3xl text-navy">Secretary-General</h2>
        <div className="mt-6 max-w-md">
          <PersonCard person={SECRETARY_GENERAL} />
        </div>
        <h2 className="display mt-14 text-3xl text-navy">Executive Board</h2>
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {EXECUTIVE_BOARD.map((person) => (
            <PersonCard key={person.name + person.role} person={person} />
          ))}
        </div>
        <h2 className="display mt-14 text-3xl text-navy">World Press</h2>
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {WORLD_PRESS_TEAM.map((person) => (
            <PersonCard key={person.name} person={person} />
          ))}
        </div>
      </section>
    </main>
  );
}
