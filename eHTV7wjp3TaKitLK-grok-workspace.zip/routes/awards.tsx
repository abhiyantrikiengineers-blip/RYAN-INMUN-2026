import { createFileRoute } from "@tanstack/react-router";
import { PageHero } from "@/components/page-hero";
import {
  BEST_COUNTRY_PROFILES,
  BEST_DELEGATIONS,
  COMMITTEE_AWARDS,
  PRESS_AWARDS,
  type Recipient,
} from "@/data/awards";
import { SITE_NAME } from "@/data/conference";

export const Route = createFileRoute("/awards")({
  head: () => ({
    meta: [
      { title: `Awards · ${SITE_NAME}` },
      {
        name: "description",
        content: `Awards and recognition from ${SITE_NAME} — Best Delegation, committee awards, and World Press.`,
      },
    ],
  }),
  component: AwardsPage,
});

function line(r: Recipient) {
  return [r.name, r.country, r.school].filter(Boolean).join(" · ");
}

function AwardsPage() {
  return (
    <main>
      <PageHero
        eyebrow="Awards"
        title="Recognition across every room."
        lede={`Congratulations to every delegate, journalist, photographer and caricaturist recognised at ${SITE_NAME}.`}
      />

      <section className="site-container py-16 md:py-20">
        <h2 className="display text-3xl text-navy">Best School Delegation</h2>
        <ul className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {BEST_DELEGATIONS.map((r) => (
            <li key={r.name} className="card-surface p-5">
              <p className="font-medium text-navy">{r.name}</p>
              <p className="text-sm text-muted">
                {r.country}
                {r.outstation ? " · Outstation" : ""}
              </p>
            </li>
          ))}
        </ul>

        <h2 className="display mt-14 text-3xl text-navy">Best Country Profile</h2>
        <ul className="mt-6 grid gap-3 sm:grid-cols-2">
          {BEST_COUNTRY_PROFILES.map((r) => (
            <li key={r.country} className="card-surface p-5">
              <p className="font-medium text-navy">{r.country}</p>
              <p className="text-sm text-muted">{r.school}</p>
            </li>
          ))}
        </ul>

        {COMMITTEE_AWARDS.map((section) => (
          <article key={section.id} className="mt-14" id={section.id}>
            <h2 className="display text-3xl text-navy">{section.title}</h2>
            {section.categories.map((cat) => (
              <div key={cat.label} className="mt-6">
                <h3 className="text-xs font-semibold uppercase tracking-[0.16em] text-muted">
                  {cat.label}
                </h3>
                <ul className="mt-3 grid gap-2">
                  {cat.recipients.map((r) => (
                    <li key={line(r)} className="border-b border-line py-3 text-sm">
                      <span className="font-medium text-navy">{r.name}</span>
                      <span className="text-muted">
                        {r.country || r.school
                          ? ` · ${[r.country, r.school].filter(Boolean).join(" · ")}`
                          : ""}
                        {r.outstation ? " · Outstation" : ""}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </article>
        ))}

        {PRESS_AWARDS.map((section) => (
          <article key={section.id} className="mt-14" id={section.id}>
            <h2 className="display text-3xl text-navy">{section.title}</h2>
            {section.categories.map((cat) => (
              <div key={cat.label} className="mt-6">
                <h3 className="text-xs font-semibold uppercase tracking-[0.16em] text-muted">
                  {cat.label}
                </h3>
                <ul className="mt-3 grid gap-2">
                  {cat.recipients.map((r) => (
                    <li key={line(r)} className="border-b border-line py-3 text-sm">
                      <span className="font-medium text-navy">{r.name}</span>
                      <span className="text-muted">{r.school ? ` · ${r.school}` : ""}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </article>
        ))}
      </section>
    </main>
  );
}
