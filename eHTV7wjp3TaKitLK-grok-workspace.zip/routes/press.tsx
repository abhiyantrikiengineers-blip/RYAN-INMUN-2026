import { createFileRoute, Link } from "@tanstack/react-router";
import { PageHero } from "@/components/page-hero";
import { PersonCard } from "@/components/person-card";
import { Button } from "@/components/ui/button";
import { PHOTO_ALBUMS, SITE_NAME } from "@/data/conference";
import { WORLD_PRESS_TEAM } from "@/data/leadership";

export const Route = createFileRoute("/press")({
  head: () => ({
    meta: [
      { title: `World Press · ${SITE_NAME}` },
      {
        name: "description",
        content: `World Press desk of ${SITE_NAME} — editors, photographers, and caricaturists.`,
      },
    ],
  }),
  component: PressPage,
});

function PressPage() {
  return (
    <main>
      <PageHero
        eyebrow="World Press"
        title="The conference, recorded as it happens."
        lede={`Journalists, photographers, and caricaturists covering ${SITE_NAME}.`}
      />
      <section className="site-container py-16 md:py-20">
        <h2 className="display text-3xl text-navy">The desk</h2>
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {WORLD_PRESS_TEAM.map((person) => (
            <PersonCard key={person.name} person={person} />
          ))}
        </div>
        <h2 className="display mt-14 text-3xl text-navy">Photograph albums</h2>
        <ul className="mt-6 grid gap-3">
          {PHOTO_ALBUMS.map((album) => (
            <li key={album.href}>
              <a
                href={album.href}
                target="_blank"
                rel="noopener noreferrer"
                className="text-navy underline-offset-4 hover:underline"
              >
                {album.label}
              </a>
            </li>
          ))}
        </ul>
        <Button asChild className="mt-8" variant="outline">
          <Link to="/awards">World Press awards</Link>
        </Button>
      </section>
    </main>
  );
}
