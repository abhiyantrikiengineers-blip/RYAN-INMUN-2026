import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function PageHero({
  eyebrow,
  title,
  lede,
  meta,
  children,
  dense = false,
}: {
  eyebrow: string;
  title: string;
  lede?: string;
  meta?: ReactNode;
  children?: ReactNode;
  dense?: boolean;
}) {
  return (
    <header
      className={cn(
        "relative overflow-hidden bg-navy text-cream",
        dense ? "pt-16 pb-14 md:pt-20 md:pb-16" : "pt-16 pb-16 md:pt-20 md:pb-20",
      )}
    >
      <div className="pointer-events-none absolute inset-0 opacity-40" aria-hidden="true">
        <div className="absolute -right-24 top-[-20%] h-[28rem] w-[28rem] rounded-full border border-cream/10" />
        <div className="absolute -right-8 top-[8%] h-[18rem] w-[18rem] rounded-full border border-cream/10" />
      </div>
      <div className="site-container relative">
        <p className="eyebrow text-accent-soft">{eyebrow}</p>
        <h1 className="display mt-5 max-w-4xl text-5xl text-cream md:text-6xl lg:text-7xl">
          {title}
        </h1>
        {lede ? (
          <p className="prose-narrow mt-5 text-base text-on-navy-muted md:text-lg">
            {lede}
          </p>
        ) : null}
        {meta ? <div className="mt-6 text-sm text-on-navy-muted">{meta}</div> : null}
        {children}
      </div>
    </header>
  );
}
