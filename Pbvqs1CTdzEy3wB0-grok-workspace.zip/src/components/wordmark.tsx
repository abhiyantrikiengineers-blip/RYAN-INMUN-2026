import { Link } from "@tanstack/react-router";
import { cn } from "@/lib/utils";
import { SITE_NAME } from "@/data/conference";

export function Wordmark({
  invert = false,
  compact = false,
}: {
  invert?: boolean;
  compact?: boolean;
}) {
  return (
    <Link
      to="/"
      aria-label={`${SITE_NAME} home`}
      className="group flex items-center gap-3"
    >
      <span
        className={cn(
          "grid size-9 place-items-center rounded-full border text-[0.65rem] font-semibold tracking-[0.12em]",
          invert
            ? "border-cream/25 text-cream"
            : "border-navy/20 text-navy",
        )}
        aria-hidden="true"
      >
        24
      </span>
      <span className="flex flex-col leading-none">
        <span
          className={cn(
            "font-display text-[1.2rem] font-semibold tracking-tight",
            invert ? "text-cream" : "text-navy",
          )}
        >
          RYAN INMUN
        </span>
        {!compact ? (
          <span
            className={cn(
              "mt-1 text-[0.62rem] font-medium uppercase tracking-[0.22em]",
              invert ? "text-on-navy-muted" : "text-muted",
            )}
          >
            2026
          </span>
        ) : (
          <span
            className={cn(
              "mt-1 text-[0.62rem] font-medium uppercase tracking-[0.22em]",
              invert ? "text-on-navy-muted" : "text-muted",
            )}
          >
            2026
          </span>
        )}
      </span>
    </Link>
  );
}
