import { useState } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { Menu, X } from "lucide-react";
import { NAV, SITE_NAME } from "@/data/conference";
import { Wordmark } from "@/components/wordmark";
import { SiteSearch } from "@/components/site-search";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <header className="sticky top-0 z-50 border-b border-cream/10 bg-navy/95 backdrop-blur-md">
      <div className="site-container flex h-[4.25rem] items-center justify-between gap-4">
        <Wordmark invert />
        <nav
          className="hidden items-center gap-6 lg:flex"
          aria-label={`${SITE_NAME} primary`}
        >
          {NAV.map((item) => {
            const active =
              pathname === item.to || pathname.startsWith(`${item.to}/`);
            return (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "nav-underline text-[0.8rem] font-medium uppercase tracking-[0.14em] text-cream/80 hover:text-cream",
                  active && "is-active text-cream",
                )}
              >
                {item.label}
              </Link>
            );
          })}
        </nav>
        <div className="flex items-center gap-2">
          <SiteSearch />
          <Button asChild size="sm" variant="invert" className="hidden sm:inline-flex">
            <Link to="/participate">Participate</Link>
          </Button>
          <button
            type="button"
            className="grid size-10 place-items-center rounded-full border border-cream/15 text-cream lg:hidden"
            aria-label={open ? "Close menu" : "Open menu"}
            aria-expanded={open}
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X className="size-5" /> : <Menu className="size-5" />}
          </button>
        </div>
      </div>
      {open ? (
        <div className="border-t border-cream/10 bg-navy px-4 py-5 lg:hidden">
          <nav className="flex flex-col gap-1" aria-label={`${SITE_NAME} mobile`}>
            {NAV.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                onClick={() => setOpen(false)}
                className="rounded-xl px-3 py-3 text-sm font-medium text-cream hover:bg-white/10"
              >
                {item.label}
              </Link>
            ))}
            <Link
              to="/press"
              onClick={() => setOpen(false)}
              className="rounded-xl px-3 py-3 text-sm font-medium text-cream hover:bg-white/10"
            >
              World Press
            </Link>
            <Button asChild className="mt-2" variant="invert">
              <Link to="/participate" onClick={() => setOpen(false)}>
                Participate
              </Link>
            </Button>
          </nav>
        </div>
      ) : null}
    </header>
  );
}
