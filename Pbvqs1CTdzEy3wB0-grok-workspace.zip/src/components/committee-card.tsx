import { Link } from "@tanstack/react-router";
import { ArrowUpRight } from "lucide-react";
import type { Committee } from "@/data/committees";
import { cn } from "@/lib/utils";

export function CommitteeCard({
  committee,
  index = 0,
}: {
  committee: Committee;
  index?: number;
}) {
  return (
    <Link
      to="/committees/$slug"
      params={{ slug: committee.slug }}
      className={cn(
        "group card-surface relative flex h-full flex-col p-6 transition-[transform,box-shadow] duration-200",
        "hover:-translate-y-1 hover:shadow-[var(--shadow-lift)]",
      )}
      style={{ transitionDelay: `${Math.min(index, 6) * 40}ms` }}
    >
      <div className="flex items-start justify-between gap-3">
        <span className="font-display text-2xl text-accent">{committee.number}</span>
        <span className="rounded-full border border-line px-2.5 py-1 text-[0.65rem] font-semibold uppercase tracking-[0.14em] text-muted">
          {committee.delegates} delegates
        </span>
      </div>
      <h3 className="mt-6 font-display text-2xl leading-tight text-navy">
        {committee.name}
      </h3>
      <p className="mt-1 text-xs font-semibold uppercase tracking-[0.16em] text-muted">
        {committee.acronym}
      </p>
      <p className="mt-4 flex-1 text-sm leading-relaxed text-muted">
        {committee.agenda}
      </p>
      <span className="mt-6 inline-flex items-center gap-1 text-sm font-medium text-navy">
        Open committee
        <ArrowUpRight className="size-4 transition-transform duration-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
      </span>
    </Link>
  );
}
