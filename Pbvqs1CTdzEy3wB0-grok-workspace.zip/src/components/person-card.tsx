import { Link } from "@tanstack/react-router";
import { initials, type Person } from "@/data/leadership";
import { cn } from "@/lib/utils";

export function PersonCard({
  person,
  featured = false,
}: {
  person: Person;
  featured?: boolean;
}) {
  const body = (
    <>
      <span
        className={cn(
          "grid size-12 place-items-center rounded-full border text-sm font-semibold tracking-wide",
          featured
            ? "border-cream/20 bg-white/5 text-cream"
            : "border-line bg-paper text-navy",
        )}
        aria-hidden="true"
      >
        {initials(person.name)}
      </span>
      <span className="min-w-0">
        <span
          className={cn(
            "block font-display text-xl leading-tight",
            featured ? "text-cream" : "text-navy",
          )}
        >
          {person.name}
        </span>
        <span
          className={cn(
            "mt-1 block text-sm",
            featured ? "text-on-navy-muted" : "text-muted",
          )}
        >
          {person.role}
        </span>
        <span
          className={cn(
            "mt-1 block text-xs uppercase tracking-[0.14em]",
            featured ? "text-cream/55" : "text-muted/80",
          )}
        >
          {person.school}
        </span>
      </span>
    </>
  );

  const className = cn(
    "flex items-start gap-4 rounded-2xl border p-5 transition-[transform,box-shadow,border-color] duration-200",
    featured
      ? "border-cream/10 bg-white/4 hover:border-cream/25"
      : "card-surface hover:-translate-y-0.5 hover:shadow-[var(--shadow-lift)]",
  );

  if (person.committeeSlug) {
    return (
      <Link
        to="/committees/$slug"
        params={{ slug: person.committeeSlug }}
        className={className}
      >
        {body}
      </Link>
    );
  }

  return <article className={className}>{body}</article>;
}
