import { Link } from "@tanstack/react-router";
import { SITE_NAME } from "@/data/conference";
import { Button } from "@/components/ui/button";

export function NotFound() {
  return (
    <main className="flex min-h-[70vh] flex-col items-center justify-center px-6 text-center">
      <p className="eyebrow">Page not found</p>
      <h1 className="display mt-4 text-5xl text-navy md:text-6xl">
        This corridor is empty.
      </h1>
      <p className="prose-narrow mt-4 text-muted">
        The page you requested is not part of {SITE_NAME}. Return to the
        conference home, or open the committees.
      </p>
      <div className="mt-8 flex flex-wrap justify-center gap-3">
        <Button asChild>
          <Link to="/">Back to home</Link>
        </Button>
        <Button asChild variant="outline">
          <Link to="/committees">View committees</Link>
        </Button>
      </div>
    </main>
  );
}
