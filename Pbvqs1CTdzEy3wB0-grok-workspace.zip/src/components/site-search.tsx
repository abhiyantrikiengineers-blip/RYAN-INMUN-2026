import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { Search, X } from "lucide-react";
import { COMMITTEES } from "@/data/committees";
import { EXECUTIVE_BOARD, SECRETARY_GENERAL, WORLD_PRESS_TEAM } from "@/data/leadership";
import { NAV, SITE_NAME } from "@/data/conference";

type Hit = { label: string; hint: string; to: string };

function buildIndex(): Hit[] {
  const pages: Hit[] = [
    { label: "Home", hint: SITE_NAME, to: "/" },
    ...NAV.map((item) => ({ label: item.label, hint: "Page", to: item.to })),
    { label: "World Press", hint: "Page", to: "/press" },
  ];
  const committees = COMMITTEES.map((c) => ({
    label: c.fullName,
    hint: c.agenda,
    to: `/committees/${c.slug}`,
  }));
  const people = [SECRETARY_GENERAL, ...EXECUTIVE_BOARD, ...WORLD_PRESS_TEAM].map(
    (person) => ({
      label: person.name,
      hint: `${person.role} · ${person.school}`,
      to: person.committeeSlug ? `/committees/${person.committeeSlug}` : "/leadership",
    }),
  );
  return [...pages, ...committees, ...people];
}

export function SiteSearch() {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const navigate = useNavigate();
  const index = useMemo(buildIndex, []);

  const hits = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return index.slice(0, 8);
    return index
      .filter(
        (hit) =>
          hit.label.toLowerCase().includes(q) || hit.hint.toLowerCase().includes(q),
      )
      .slice(0, 10);
  }, [index, query]);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        setOpen(true);
      }
      if (event.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  useEffect(() => {
    if (!open) setQuery("");
  }, [open]);

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="inline-flex h-10 items-center gap-2 rounded-full border border-cream/15 bg-white/5 px-3 text-sm text-on-navy-muted transition-colors hover:border-cream/30 hover:text-cream"
        aria-label={`Search ${SITE_NAME}`}
      >
        <Search className="size-4" strokeWidth={1.75} />
        <span className="hidden md:inline">Search</span>
      </button>
      {open ? (
        <div
          className="fixed inset-0 z-80 flex items-start justify-center bg-navy/70 px-4 pt-[12vh] backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
          aria-label={`Search ${SITE_NAME}`}
          onClick={() => setOpen(false)}
        >
          <div
            className="w-full max-w-xl overflow-hidden rounded-2xl border border-line bg-cream shadow-[0_24px_80px_-24px_rgba(8,20,34,0.55)]"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-3 border-b border-line px-4">
              <Search className="size-4 text-muted" />
              <input
                autoFocus
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Committees, people, pages…"
                className="h-14 flex-1 bg-transparent text-base text-ink outline-none placeholder:text-muted"
              />
              <button
                type="button"
                onClick={() => setOpen(false)}
                className="grid size-9 place-items-center rounded-full text-muted hover:bg-paper-2 hover:text-ink"
                aria-label="Close search"
              >
                <X className="size-4" />
              </button>
            </div>
            <ul className="max-h-[50vh] overflow-y-auto p-2">
              {hits.length === 0 ? (
                <li className="px-3 py-8 text-center text-sm text-muted">
                  No matches in {SITE_NAME}.
                </li>
              ) : (
                hits.map((hit) => (
                  <li key={`${hit.to}-${hit.label}`}>
                    <Link
                      to={hit.to}
                      onClick={() => {
                        setOpen(false);
                        void navigate({ to: hit.to });
                      }}
                      className="block rounded-xl px-3 py-3 transition-colors hover:bg-paper-2"
                    >
                      <div className="text-sm font-medium text-ink">{hit.label}</div>
                      <div className="mt-0.5 line-clamp-1 text-xs text-muted">
                        {hit.hint}
                      </div>
                    </Link>
                  </li>
                ))
              )}
            </ul>
          </div>
        </div>
      ) : null}
    </>
  );
}
