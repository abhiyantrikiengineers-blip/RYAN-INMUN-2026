import { Link } from "@tanstack/react-router";
import {
  CONFERENCE,
  CONTACTS,
  FOOTER_NAV,
  SITE_NAME,
  SITE_TAGLINE,
} from "@/data/conference";
import { Wordmark } from "@/components/wordmark";

export function SiteFooter() {
  return (
    <footer className="bg-navy text-cream">
      <div className="site-container grid gap-12 py-16 md:grid-cols-[1.4fr_1fr_1fr]">
        <div>
          <Wordmark invert />
          <p className="mt-5 max-w-sm text-sm leading-relaxed text-on-navy-muted">
            {SITE_TAGLINE}. India’s longest-running Model United Nations,
            hosted by the {CONFERENCE.host}.
          </p>
          <p className="mt-4 text-sm text-cream/90">
            {CONFERENCE.datesShort}
            <span className="mx-2 text-cream/30">·</span>
            {CONFERENCE.venue}
          </p>
        </div>
        <div>
          <p className="text-[0.7rem] font-semibold uppercase tracking-[0.18em] text-on-navy-muted">
            Explore
          </p>
          <ul className="mt-4 grid gap-2">
            {FOOTER_NAV.map((item) => (
              <li key={item.to}>
                <Link
                  to={item.to}
                  className="text-sm text-cream/85 transition-colors hover:text-cream"
                >
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <p className="text-[0.7rem] font-semibold uppercase tracking-[0.18em] text-on-navy-muted">
            Coordinators
          </p>
          <ul className="mt-4 grid gap-5">
            {CONTACTS.map((person) => (
              <li key={person.email}>
                <p className="text-sm font-medium text-cream">{person.name}</p>
                <p className="text-xs text-on-navy-muted">
                  {person.role} · {person.region}
                </p>
                <a
                  href={`mailto:${person.email}`}
                  className="mt-1 inline-block text-sm text-accent-soft underline-offset-4 hover:underline"
                >
                  {person.email}
                </a>
              </li>
            ))}
          </ul>
        </div>
      </div>
      <div className="border-t border-cream/10">
        <div className="site-container flex flex-col gap-2 py-5 text-xs text-on-navy-muted sm:flex-row sm:items-center sm:justify-between">
          <p>
            © {SITE_NAME}. {CONFERENCE.host}.
          </p>
          <p>SCOPE Complex · New Delhi</p>
        </div>
      </div>
    </footer>
  );
}
