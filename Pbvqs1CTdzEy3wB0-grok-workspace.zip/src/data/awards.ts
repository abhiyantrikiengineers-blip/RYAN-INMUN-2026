export type Recipient = {
  name: string;
  country?: string;
  school?: string;
  outstation?: boolean;
};

export type AwardCategory = {
  label: string;
  recipients: Recipient[];
};

export type AwardSection = {
  id: string;
  title: string;
  categories: AwardCategory[];
};

export const BEST_DELEGATIONS: Recipient[] = [
  { name: "RIS Vasant Kunj", country: "India" },
  { name: "RIS Greater Noida", country: "Brazil" },
  { name: "RIS Noida", country: "Iran" },
  { name: "RIS Rohini", country: "Saudi Arabia" },
  { name: "RIS Mayur Vihar", country: "South Africa" },
  { name: "RIS Bavdhan, Pune", country: "Slovakia", outstation: true },
];

export const BEST_COUNTRY_PROFILES: Recipient[] = [
  { country: "Brazil", school: "Ryan International School (ICSE), Malad" },
  { country: "India", school: "Ryan International School, Vasant Kunj" },
  { country: "Indonesia", school: "Ryan International School, Faridabad" },
  { country: "Iran", school: "Ryan International School, Noida" },
  { country: "Myanmar", school: "St. Xavier's High School, Goregaon East" },
  { country: "Panama", school: "St. Lawrence High School, Borivali" },
  { country: "Portugal & Sweden", school: "Ryan International School, G-2 Sector 11, Rohini" },
  { country: "Singapore", school: "Ryan International School, H-3, Sector-11, Rohini" },
  { country: "South Africa", school: "Ryan International School, Mayur Vihar" },
  { country: "Uruguay & Peru", school: "Ryan International School, Masdar" },
].map((row) => ({ name: row.country, country: row.country, school: row.school }));

export const COMMITTEE_AWARDS: AwardSection[] = [
  {
    id: "icj",
    title: "International Court of Justice",
    categories: [
      {
        label: "Best Delegate",
        recipients: [
          { name: "Hrishi", country: "Brazil 1", school: "RIS Greater Noida" },
          { name: "Divyanshi Malhotra", country: "Iran", school: "RIS Noida" },
          { name: "Keshav Dawar", country: "Saudi Arabia", school: "RIS Rohini" },
        ],
      },
      {
        label: "High Commendation",
        recipients: [
          { name: "Aditya Dutta", country: "United States", school: "Cambridge Kandivali" },
          { name: "Aarav Verma", country: "Belgium", school: "RIS Ghaziabad" },
          { name: "Aayush Jindal", country: "Singapore", school: "RIS Rohini H3" },
          { name: "Diya Jasra", country: "Jordan", school: "RIS Ludhiana", outstation: true },
        ],
      },
      {
        label: "Special Mention",
        recipients: [
          { name: "Tanmay Kumar", country: "South Africa", school: "RIS Mayur Vihar" },
          { name: "Ashutosh Singh", country: "Malaysia", school: "RIS Sohna Road" },
          { name: "Preksha Sharma", country: "Indonesia", school: "RIS Faridabad" },
          { name: "Isahnvi Releekar", country: "Slovakia", school: "RIS Bavdhan, Pune", outstation: true },
          { name: "Gunreet Kaur", country: "Romania", school: "RIS Patiala", outstation: true },
        ],
      },
    ],
  },
  {
    id: "disec",
    title: "UN General Assembly DISEC",
    categories: [
      {
        label: "Best Delegate",
        recipients: [
          { name: "Akshat & Inoday", country: "Israel", school: "RIS Ghaziabad" },
          { name: "Anubhab Singha Roy", country: "Indonesia", school: "RIS Faridabad" },
          { name: "Soumya", country: "Iran", school: "RIS Noida" },
          { name: "Viraj Lamba & Aayush Chakraborty", country: "Malaysia", school: "RIS Sohna Road" },
          { name: "Sarthak & Jatin", country: "South Africa", school: "RIS Mayur Vihar" },
          { name: "Hardik Singhal & Aarush Verma", country: "Saudi Arabia", school: "RIS Rohini" },
        ],
      },
      {
        label: "High Commendation",
        recipients: [
          { name: "Shaurya Pratap Singh & Suvir Thakur", country: "Qatar", school: "RIS Greater Noida" },
          { name: "Viraaj Singh & Zoya Naaz", country: "Brazil 1", school: "RIS Greater Noida" },
          { name: "Aanya Rai & Eris Tamang", country: "India", school: "RIS Vasant Kunj" },
          { name: "Mahika Singhal", country: "Singapore", school: "RIS Rohini H3" },
          { name: "Arjun Kirsur & Niel Shetty", country: "Iraq", school: "Cambridge Kandivali", outstation: true },
        ],
      },
      {
        label: "Special Mention",
        recipients: [
          { name: "Shashwat", country: "Chad", school: "RIS Sohna Road" },
          { name: "Diva & Dishita", country: "Morocco", school: "RIS Faridabad" },
          { name: "Kshitish & Aahana", country: "Belgium", school: "RIS Ghaziabad" },
          { name: "Manya Agarwal & Kashvi Gulyani", country: "Spain", school: "RIS Rohini H3" },
          { name: "Mrigank & Jagrit", country: "Mexico", school: "RIS Faridabad" },
          { name: "Suryanshi Singh", country: "Uganda", school: "RIS Ghaziabad" },
          { name: "Pratyush Kale & Ameya Kale", country: "Slovakia", school: "RIS Bavdhan, Pune", outstation: true },
          { name: "Susweta Behera & Aditya Angane", country: "United States", school: "RIS Kandivali", outstation: true },
        ],
      },
    ],
  },
  {
    id: "cd",
    title: "Conference on Disarmament",
    categories: [
      {
        label: "Best Delegate",
        recipients: [
          { name: "Shresth Jha", country: "South Africa", school: "RIS Mayur Vihar" },
          { name: "Saanvi Bajaj", country: "India", school: "RIS Vasant Kunj" },
          { name: "Arohi Yadav", country: "Iran", school: "RIS Noida" },
          { name: "Devansh Siwach", country: "Brazil 1", school: "RIS Greater Noida" },
        ],
      },
      {
        label: "High Commendation",
        recipients: [
          { name: "Atulya Pandey", country: "Saudi Arabia", school: "RIS Rohini" },
          { name: "Arshit Aggarwal", country: "Ghana", school: "RIS Rohini G2" },
          { name: "Aarav Shukla", country: "Indonesia", school: "RIS Faridabad" },
          { name: "Navya N Ratudi", country: "United Arab Emirates", school: "RIS Kandivali", outstation: true },
        ],
      },
      {
        label: "Special Mention",
        recipients: [
          { name: "Sraghvi Dutta", country: "Russia", school: "RIS Vasant Kunj" },
          { name: "Devansh Yadav", country: "Mexico", school: "RIS Faridabad" },
          { name: "Aarav Nautiyal", country: "United States", school: "RIS Kandivali", outstation: true },
          { name: "Aaradhya Singh", country: "United Kingdom", school: "RIS Malad ICSE", outstation: true },
        ],
      },
    ],
  },
  {
    id: "ai-impact-summit",
    title: "AI Impact Summit",
    categories: [
      {
        label: "Best Delegate",
        recipients: [
          { name: "Shreya Choudhary", country: "Saudi Arabia", school: "RIS Rohini" },
          { name: "Saransh Sharma", country: "India", school: "RIS Vasant Kunj" },
          { name: "Shaurya Kakkar", country: "South Africa", school: "RIS Mayur Vihar" },
          { name: "Aditya Mishra", country: "Brazil 1", school: "RIS Greater Noida" },
        ],
      },
      {
        label: "High Commendation",
        recipients: [
          { name: "Swayyam Balyan", country: "Malaysia", school: "RIS Sohna Road" },
          { name: "Aydin Khan", country: "Indonesia", school: "RIS Faridabad" },
          { name: "Amishi Sinha", country: "Australia", school: "RIS Rohini" },
          { name: "Prabhav Khanduri", country: "China", school: "RIS Noida" },
          { name: "Aaditya Saxena", country: "Slovakia", school: "RIS Bavdhan, Pune", outstation: true },
        ],
      },
      {
        label: "Special Mention",
        recipients: [
          { name: "Bhavya", country: "Ukraine", school: "RIS Noida" },
          { name: "Jeetanshika Kaushik", country: "Kenya", school: "RIS Ghaziabad" },
          { name: "Daksh Goyal", country: "Iran", school: "RIS Noida" },
          { name: "Aradhya Gupta", country: "Israel", school: "RIS Ghaziabad" },
          { name: "Gaurang Sharma", country: "Hungary", school: "RIS Mayur Vihar" },
          { name: "Simar Kaur", country: "Mexico", school: "RIS Faridabad" },
          { name: "Jehann Silwal", country: "Jamaica" },
          { name: "Ahad Khan", country: "United States", outstation: true },
          { name: "Mst. Mahender K", country: "Liechtenstein", school: "RIS Bannerghatta ICSE", outstation: true },
        ],
      },
    ],
  },
  {
    id: "inc-5",
    title: "Intergovernmental Negotiating Committee",
    categories: [
      {
        label: "Best Delegate",
        recipients: [
          { name: "Pihu", country: "Iran", school: "RIS Noida" },
          { name: "Mysha Saifi", country: "Bangladesh", school: "RIS Faridabad" },
          { name: "Namish Garg", country: "India", school: "RIS Vasant Kunj" },
        ],
      },
      {
        label: "High Commendation",
        recipients: [
          { name: "Manan Gupta", country: "Brazil 1", school: "RIS Greater Noida" },
          { name: "Divyansh Singh", country: "Israel", school: "RIS Ghaziabad" },
          { name: "Aarav Bhavesh Chauhan", country: "United States", school: "Cambridge Kandivali", outstation: true },
          { name: "Sanvi Latey", country: "United Kingdom", school: "RIS Bavdhan, Pune", outstation: true },
        ],
      },
      {
        label: "Special Mention",
        recipients: [
          { name: "Peehu Mishra", country: "Ireland" },
          { name: "Agamya Sharma", country: "Saudi Arabia", school: "RIS Rohini" },
          { name: "Ananya Belwal", country: "South Africa", school: "RIS Mayur Vihar" },
          { name: "Diya Gupta", country: "Pakistan" },
          { name: "Rupender Singh", country: "Malaysia", school: "RIS Sohna Road" },
          { name: "Khyati Parashar", country: "Kenya", school: "RIS Ghaziabad" },
          { name: "Khanak Chawla", country: "Singapore", school: "RIS Rohini H3" },
          { name: "Vaishnavi Baluni", country: "Indonesia", school: "RIS Faridabad" },
          { name: "Rishi Arjun", country: "Iraq", school: "Cambridge Kandivali", outstation: true },
        ],
      },
    ],
  },
  {
    id: "wef",
    title: "World Economic Forum",
    categories: [
      {
        label: "Best Delegate",
        recipients: [
          { name: "Ananya Rana", country: "India", school: "RIS Vasant Kunj" },
          { name: "Angelica Vivek Raj", country: "Malaysia", school: "RIS Sohna Road" },
          { name: "Aryan Tejas Bonde", country: "South Africa", school: "RIS Mayur Vihar" },
        ],
      },
      {
        label: "High Commendation",
        recipients: [
          { name: "Agrima Singh", country: "Indonesia", school: "RIS Faridabad" },
          { name: "Aaron S Pratheep", country: "Mexico", school: "RIS Faridabad" },
          { name: "Aarush Paskanti", country: "Iceland", school: "SJHS Panvel", outstation: true },
        ],
      },
      {
        label: "Special Mention",
        recipients: [
          { name: "Mahika Lakhmara", country: "Iran", school: "RIS Noida" },
          { name: "Suyash Choudhary", country: "Saudi Arabia", school: "RIS Rohini" },
          { name: "Deepanshu Singh", country: "Belgium", school: "RIS Ghaziabad" },
          { name: "Kabeer Kaaliyaan", country: "Switzerland", school: "RIS Ojhar", outstation: true },
          { name: "Abhinav Pathania", country: "France", school: "RIS Ludhiana", outstation: true },
        ],
      },
    ],
  },
  {
    id: "g77",
    title: "Group of 77",
    categories: [
      {
        label: "Best Delegate",
        recipients: [
          { name: "Akshat Kumar Mishra", country: "South Africa", school: "RIS Mayur Vihar" },
          { name: "Ritisha", country: "Saudi Arabia", school: "RIS Rohini" },
          { name: "Pulkit", country: "Indonesia", school: "RIS Faridabad" },
          { name: "Parimita Raheja", country: "India", school: "RIS Vasant Kunj" },
        ],
      },
      {
        label: "High Commendation",
        recipients: [
          { name: "Manhar Sharma", country: "Iran", school: "RIS Noida" },
          { name: "Saransh Dubey", country: "New Zealand", school: "RIS Mansarovar Jaipur", outstation: true },
        ],
      },
      {
        label: "Special Mention",
        recipients: [
          { name: "Rudra Pratap Singh", country: "Brazil 1", school: "RIS Greater Noida" },
          { name: "Agria Agarwal", country: "Singapore", school: "RIS Rohini H3" },
          { name: "Soubhik Biswas", country: "Kuwait", school: "RIS Bannerghatta ICSE", outstation: true },
        ],
      },
    ],
  },
  {
    id: "interpol",
    title: "INTERPOL",
    categories: [
      {
        label: "Best Delegate",
        recipients: [
          { name: "Ansh Bhakuni", country: "South Africa", school: "RIS Mayur Vihar" },
          { name: "Tanish Khanna", country: "Brazil 1", school: "RIS Greater Noida" },
        ],
      },
      {
        label: "High Commendation",
        recipients: [
          { name: "Janvi Malhan", country: "Malaysia", school: "RIS Sohna Road" },
          { name: "Shashanth", country: "Iran", school: "RIS Noida" },
          { name: "Agrim Goel", country: "Singapore", school: "RIS Rohini H3" },
          { name: "Ayanna Garg", country: "Saudi Arabia", school: "RIS Rohini" },
          { name: "Atharv Saraf", country: "United Kingdom", school: "RIS Bavdhan, Pune", outstation: true },
        ],
      },
      {
        label: "Special Mention",
        recipients: [
          { name: "Rishi Ozha", country: "China" },
          { name: "Arnav Sharma", country: "Belgium" },
          { name: "Manveer Singh", country: "Indonesia" },
          { name: "Parth Saini", country: "Panama", school: "RIS Shahjahanpur", outstation: true },
          { name: "Siya Pareek", country: "France", outstation: true },
        ],
      },
    ],
  },
  {
    id: "brics",
    title: "BRICS",
    categories: [
      {
        label: "Best Delegate",
        recipients: [
          { name: "Rableen Beri", country: "Saudi Arabia", school: "RIS Rohini" },
          { name: "Devansh", country: "Brazil 1", school: "RIS Greater Noida" },
        ],
      },
      {
        label: "High Commendation",
        recipients: [
          { name: "Prakul Kumar Jain", country: "Malaysia", school: "RIS Sohna Road" },
          { name: "Swapnoneel Roy Chowdhury", country: "Indonesia", school: "RIS Faridabad" },
          { name: "Soham Rahul Thombare", country: "Belarus", school: "SJHS Kalamboli", outstation: true },
        ],
      },
      {
        label: "Special Mention",
        recipients: [
          { name: "Anandha Vishnu", country: "Mexico", school: "RIS Faridabad" },
          { name: "Tannmay Jain", country: "South Africa", school: "RIS Mayur Vihar" },
          { name: "Chahat Chettri", country: "China", school: "RIS Greater Noida" },
          { name: "Aradhya Ranjan", country: "Nigeria", school: "RIS Mayur Vihar" },
          { name: "Ananya", country: "Bangladesh", school: "RIS Faridabad" },
          { name: "Shravani Babasaheb Tadakhe", country: "Cuba", school: "RIS Nerul", outstation: true },
          { name: "Ishayu Ghosh", country: "Vietnam", school: "RIS Goregaon", outstation: true },
        ],
      },
    ],
  },
];

export const PRESS_AWARDS: AwardSection[] = [
  {
    id: "journalists",
    title: "World Press — Journalists",
    categories: [
      {
        label: "Best Journalist",
        recipients: [{ name: "Avika Singh", school: "RIS Mayur Vihar" }],
      },
      {
        label: "High Commendation",
        recipients: [
          { name: "Raghav Singh Tanwar", school: "RIS Vasant Kunj" },
          { name: "Aarna Narang", school: "RIS Rohini" },
        ],
      },
      {
        label: "Special Mention",
        recipients: [
          { name: "Diya Rustagi", school: "RIS Mayur Vihar" },
          { name: "Prachita Sehgal", school: "RIS Mayur Vihar" },
          { name: "Anahad Kaur", school: "RIS Amritsar" },
          { name: "Hriday Telang", school: "RIS Noida" },
        ],
      },
    ],
  },
  {
    id: "photographers",
    title: "World Press — Photographers",
    categories: [
      {
        label: "Best Photographer",
        recipients: [{ name: "Enam Abel Gordon", school: "RIS Noida" }],
      },
      {
        label: "High Commendation",
        recipients: [
          { name: "Maira Rajpoot", school: "RIS Rohini" },
          { name: "Vaibhav Kumar", school: "RIS Vasant Kunj" },
        ],
      },
      {
        label: "Special Mention",
        recipients: [
          { name: "Parthavi Banerjee", school: "RIS Faridabad" },
          { name: "Naman Singh", school: "RIS Mayur Vihar" },
        ],
      },
    ],
  },
  {
    id: "caricaturists",
    title: "World Press — Caricaturists",
    categories: [
      {
        label: "Best Caricaturist",
        recipients: [{ name: "Karishma Pahuja", school: "RIS Mayur Vihar" }],
      },
      {
        label: "High Commendation",
        recipients: [
          { name: "Saesha Choudhary", school: "RIS Rohini" },
          { name: "Mysha Haider", school: "RIS Mayur Vihar" },
        ],
      },
      {
        label: "Special Mention",
        recipients: [
          { name: "Manshi Chauhan", school: "RIS Mayur Vihar" },
          { name: "Ishita Bansal", school: "RIS Mayur Vihar" },
        ],
      },
    ],
  },
];
