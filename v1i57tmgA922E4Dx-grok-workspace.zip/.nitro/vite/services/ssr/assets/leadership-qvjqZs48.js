import { d as SITE_NAME } from "./conference-DkR9jBTp.js";
import { n as SECRETARY_GENERAL, r as WORLD_PRESS_TEAM, t as EXECUTIVE_BOARD } from "./leadership-C3FxZGVA.js";
import { t as PageHero } from "./page-hero-Boob4Mvt.js";
import { t as PersonCard } from "./person-card-BzPeLEXd.js";
import { jsx, jsxs } from "react/jsx-runtime";
//#region src/routes/leadership.tsx?tsr-split=component
function LeadershipPage() {
	return /* @__PURE__ */ jsxs("main", { children: [/* @__PURE__ */ jsx(PageHero, {
		eyebrow: "Leadership",
		title: "The board that runs the rooms.",
		lede: `The Secretary-General, committee chairs, and World Press desk of ${SITE_NAME}.`
	}), /* @__PURE__ */ jsxs("section", {
		className: "site-container py-16 md:py-20",
		children: [
			/* @__PURE__ */ jsx("h2", {
				className: "display text-3xl text-navy",
				children: "Secretary-General"
			}),
			/* @__PURE__ */ jsx("div", {
				className: "mt-6 max-w-md",
				children: /* @__PURE__ */ jsx(PersonCard, { person: SECRETARY_GENERAL })
			}),
			/* @__PURE__ */ jsx("h2", {
				className: "display mt-14 text-3xl text-navy",
				children: "Executive Board"
			}),
			/* @__PURE__ */ jsx("div", {
				className: "mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
				children: EXECUTIVE_BOARD.map((person) => /* @__PURE__ */ jsx(PersonCard, { person }, person.name + person.role))
			}),
			/* @__PURE__ */ jsx("h2", {
				className: "display mt-14 text-3xl text-navy",
				children: "World Press"
			}),
			/* @__PURE__ */ jsx("div", {
				className: "mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
				children: WORLD_PRESS_TEAM.map((person) => /* @__PURE__ */ jsx(PersonCard, { person }, person.name))
			})
		]
	})] });
}
//#endregion
export { LeadershipPage as component };
