import { c as PHOTO_ALBUMS, d as SITE_NAME } from "./conference-DkR9jBTp.js";
import { r as WORLD_PRESS_TEAM } from "./leadership-C3FxZGVA.js";
import { r as Button } from "./router-DCuuzYYV.js";
import { t as PageHero } from "./page-hero-Boob4Mvt.js";
import { t as PersonCard } from "./person-card-BzPeLEXd.js";
import { Link } from "@tanstack/react-router";
import { jsx, jsxs } from "react/jsx-runtime";
//#region src/routes/press.tsx?tsr-split=component
function PressPage() {
	return /* @__PURE__ */ jsxs("main", { children: [/* @__PURE__ */ jsx(PageHero, {
		eyebrow: "World Press",
		title: "The conference, recorded as it happens.",
		lede: `Journalists, photographers, and caricaturists covering ${SITE_NAME}.`
	}), /* @__PURE__ */ jsxs("section", {
		className: "site-container py-16 md:py-20",
		children: [
			/* @__PURE__ */ jsx("h2", {
				className: "display text-3xl text-navy",
				children: "The desk"
			}),
			/* @__PURE__ */ jsx("div", {
				className: "mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
				children: WORLD_PRESS_TEAM.map((person) => /* @__PURE__ */ jsx(PersonCard, { person }, person.name))
			}),
			/* @__PURE__ */ jsx("h2", {
				className: "display mt-14 text-3xl text-navy",
				children: "Photograph albums"
			}),
			/* @__PURE__ */ jsx("ul", {
				className: "mt-6 grid gap-3",
				children: PHOTO_ALBUMS.map((album) => /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx("a", {
					href: album.href,
					target: "_blank",
					rel: "noopener noreferrer",
					className: "text-navy underline-offset-4 hover:underline",
					children: album.label
				}) }, album.href))
			}),
			/* @__PURE__ */ jsx(Button, {
				asChild: true,
				className: "mt-8",
				variant: "outline",
				children: /* @__PURE__ */ jsx(Link, {
					to: "/awards",
					children: "World Press awards"
				})
			})
		]
	})] });
}
//#endregion
export { PressPage as component };
