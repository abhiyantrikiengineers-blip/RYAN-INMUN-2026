import { d as SITE_NAME } from "./conference-DkR9jBTp.js";
import { n as Route, r as Button } from "./router-DCuuzYYV.js";
import { t as PageHero } from "./page-hero-Boob4Mvt.js";
import { t as PersonCard } from "./person-card-BzPeLEXd.js";
import { Link } from "@tanstack/react-router";
import { jsx, jsxs } from "react/jsx-runtime";
//#region src/routes/committees/$slug.tsx?tsr-split=component
function CommitteeDetail() {
	const { committee, chairs } = Route.useLoaderData();
	return /* @__PURE__ */ jsxs("main", { children: [/* @__PURE__ */ jsx(PageHero, {
		eyebrow: `${committee.number} · ${committee.acronym}`,
		title: committee.fullName,
		lede: committee.agenda,
		meta: /* @__PURE__ */ jsxs("span", { children: [
			committee.delegates,
			" delegates",
			/* @__PURE__ */ jsx("span", {
				className: "mx-2 opacity-40",
				children: "·"
			}),
			/* @__PURE__ */ jsx(Link, {
				to: "/committees",
				className: "underline-offset-4 hover:underline",
				children: "All committees"
			})
		] })
	}), /* @__PURE__ */ jsxs("section", {
		className: "site-container grid gap-12 py-16 lg:grid-cols-[1.2fr_0.8fr] md:py-20",
		children: [/* @__PURE__ */ jsxs("div", { children: [
			/* @__PURE__ */ jsx("h2", {
				className: "display text-3xl text-navy",
				children: "The agenda"
			}),
			/* @__PURE__ */ jsx("p", {
				className: "mt-4 max-w-prose text-muted",
				children: committee.summary
			}),
			/* @__PURE__ */ jsx("h3", {
				className: "mt-10 text-sm font-semibold uppercase tracking-[0.16em] text-muted",
				children: "Questions to research"
			}),
			/* @__PURE__ */ jsx("ol", {
				className: "mt-4 grid gap-3",
				children: committee.questions.map((q, i) => /* @__PURE__ */ jsxs("li", {
					className: "card-surface flex gap-4 p-5",
					children: [/* @__PURE__ */ jsx("span", {
						className: "font-display text-xl text-accent",
						children: String(i + 1).padStart(2, "0")
					}), /* @__PURE__ */ jsx("p", {
						className: "text-sm leading-relaxed text-ink",
						children: q
					})]
				}, q))
			})
		] }), /* @__PURE__ */ jsxs("aside", {
			className: "grid gap-4 self-start",
			children: [
				/* @__PURE__ */ jsx("h2", {
					className: "display text-2xl text-navy",
					children: "Executive Board"
				}),
				chairs.length ? chairs.map((person) => /* @__PURE__ */ jsx(PersonCard, { person }, person.name)) : /* @__PURE__ */ jsx("p", {
					className: "text-sm text-muted",
					children: "Chairs listed on the leadership page."
				}),
				/* @__PURE__ */ jsx(Button, {
					asChild: true,
					className: "mt-2",
					children: /* @__PURE__ */ jsxs(Link, {
						to: "/participate",
						children: ["Register for ", SITE_NAME]
					})
				})
			]
		})]
	})] });
}
//#endregion
export { CommitteeDetail as component };
