import { t as cn } from "./utils-C_uf36nf.js";
import { useEffect, useRef } from "react";
import { jsx } from "react/jsx-runtime";
//#region src/components/reveal.tsx
function Reveal({ children, className, delay = 0 }) {
	const ref = useRef(null);
	useEffect(() => {
		const node = ref.current;
		if (!node) return;
		if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
			node.classList.add("is-in");
			return;
		}
		const observer = new IntersectionObserver(([entry]) => {
			if (entry?.isIntersecting) {
				node.classList.add("is-in");
				observer.disconnect();
			}
		}, {
			threshold: .12,
			rootMargin: "0px 0px -8% 0px"
		});
		observer.observe(node);
		return () => observer.disconnect();
	}, []);
	return /* @__PURE__ */ jsx("div", {
		ref,
		className: cn("reveal", className),
		style: { transitionDelay: delay ? `${delay}ms` : void 0 },
		children
	});
}
//#endregion
export { Reveal as t };
