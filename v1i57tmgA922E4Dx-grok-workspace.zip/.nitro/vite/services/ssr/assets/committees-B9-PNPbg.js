//#region src/data/committees.ts
var COMMITTEES = [
	{
		slug: "icj",
		number: "01",
		acronym: "ICJ",
		name: "International Court of Justice",
		fullName: "International Court of Justice (ICJ)",
		agenda: "Relocation of the United States Embassy to Jerusalem",
		delegates: 36,
		summary: "The relocation of the US Embassy to Jerusalem in 2018 sparked one of the most high-profile disputes in international law. Palestine challenged the move at the ICJ, arguing it violates international obligations. The case raises questions about the legality of unilateral recognition of contested territories and the limits of state sovereignty.",
		questions: [
			"Does US recognition of Jerusalem as Israel’s capital violate its obligations under international law?",
			"To what extent can ICJ rulings constrain a powerful state that rejects the Court’s jurisdiction?",
			"Can Palestine claim reparations or legal remedies, and what form might these take?",
			"What precedent does this case set for other territorial disputes worldwide?"
		]
	},
	{
		slug: "disec",
		number: "02",
		acronym: "DISEC",
		name: "UN General Assembly — DISEC",
		fullName: "UNGA I — DISEC",
		agenda: "Breaking Point: Prospects for Peace in the Middle East",
		delegates: 302,
		summary: "The Middle East remains a tinderbox of unresolved conflicts, shifting alliances, and deep-seated grievances. Recent years have seen escalating tensions from renewed hostilities in Gaza and the West Bank to proxy conflicts across Yemen and Syria. With energy security, migration, and humanitarian crises intertwined, the region’s instability resonates far beyond its borders.",
		questions: [
			"How did the latest outbreak of violence come about, and could it have been prevented?",
			"Are current US strategies in the region effective, or are they misread by Tehran and other actors?",
			"Can longstanding rivalries be reconciled, and is there space for dialogue between historic adversaries?",
			"What realistic pathways exist for enduring stability this year and over the next decade?"
		]
	},
	{
		slug: "cd",
		number: "03",
		acronym: "CD",
		name: "Conference on Disarmament",
		fullName: "Conference on Disarmament (CD)",
		agenda: "War for Hire: Regulating the Privatisation of Armed Conflicts",
		delegates: 116,
		summary: "Private military contractors and armed corporations are increasingly operating in conflicts once reserved for states. From Ukraine to Africa and the Middle East, these actors blur the lines between legitimate defence and profit-driven combat. Accountability remains murky while the human cost continues to mount.",
		questions: [
			"How can international law adapt to private militaries without discouraging legitimate defence contractors?",
			"Should there be global licensing or oversight mechanisms for armed companies?",
			"Can profit motives ever align with humanitarian objectives?",
			"How can accountability be ensured for human rights abuses by non-state combatants?"
		]
	},
	{
		slug: "ai-impact-summit",
		number: "04",
		acronym: "AI IS",
		name: "AI Impact Summit",
		fullName: "AI Impact Summit (AI IS)",
		agenda: "Competition for Computation: The Geopolitics of the AI Infrastructure Boom",
		delegates: 113,
		summary: "Artificial intelligence is now a defining arena of global power and strategic rivalry. Much like nuclear technology during the Cold War, AI shapes economic primacy, military capability, and societal influence. Control over semiconductors, cloud infrastructure, and algorithmic innovation is becoming synonymous with sovereignty.",
		questions: [
			"How can nations balance technological ambition with ethical governance?",
			"How should the Global South avoid marginalisation in a fragmented AI order?",
			"Can international cooperation on standards coexist with great-power rivalry?",
			"What strategies can prevent parallel AI blocs from destabilising the international order?"
		]
	},
	{
		slug: "inc-5",
		number: "05",
		acronym: "INC-5",
		name: "Intergovernmental Negotiating Committee",
		fullName: "Intergovernmental Negotiating Committee (INC-5)",
		agenda: "Wrap It Up: Delivering a Global Plastics Treaty",
		delegates: 110,
		summary: "The world produces over 400 million tonnes of plastic every year, yet less than 10 per cent is recycled effectively. Plastic pollution has infiltrated every corner of the planet. Despite numerous national policies and voluntary corporate initiatives, the global response has remained fragmented.",
		questions: [
			"How can a binding treaty address production, consumption, and disposal simultaneously?",
			"Should the treaty include legally enforceable targets or rely on voluntary commitments?",
			"How can developing nations be supported in managing plastic waste effectively?",
			"What steps ensure global commitments translate into measurable action?"
		]
	},
	{
		slug: "wef",
		number: "06",
		acronym: "WEF",
		name: "World Economic Forum",
		fullName: "World Economic Forum (WEF)",
		agenda: "Work in Progress: Jobs, Taxes, and the Social Safety Net",
		delegates: 56,
		summary: "Labour markets are being reshaped at breakneck speed. AI is automating tasks once thought secure, platform work is blurring the line between employment and entrepreneurship, and demographic shifts are straining pension systems. From wealth taxes to universal basic income, the global policy playbook is being rewritten in real time.",
		questions: [
			"How should tax systems adapt to an economy where capital moves freely but workers cannot?",
			"Who should bear the cost of reskilling workers displaced by automation?",
			"Do gig workers deserve the same protections as traditional employees?",
			"Should corporations benefiting most from digitalisation contribute more?"
		]
	},
	{
		slug: "g77",
		number: "07",
		acronym: "G77",
		name: "Group of 77",
		fullName: "Group of 77 (G77)",
		agenda: "Tariff-fying Times: Managing the Weaponisation of Trade",
		delegates: 52,
		summary: "Global trade is under unprecedented strain as economic power is increasingly used as a tool of coercion. US tariffs and export controls have sent shockwaves across markets, while China’s aggressive industrial policies unsettle industries worldwide. For G77 nations, the challenge is how to secure growth without being caught in the crossfire of geoeconomic rivalry.",
		questions: [
			"How can G77 countries navigate Washington’s trade strategies while safeguarding domestic industries?",
			"Can the WTO rules-based system survive, or should countries turn to regional alliances?",
			"How can the Group leverage collective influence to promote fair trade?"
		]
	},
	{
		slug: "interpol",
		number: "08",
		acronym: "INTERPOL",
		name: "INTERPOL",
		fullName: "International Criminal Police Organisation (INTERPOL)",
		agenda: "Illicit Affairs: Confronting Criminal Networks Across Borders",
		delegates: 47,
		summary: "Criminal networks move money, weapons, people, and data across continents with ease, exploiting porous borders and digital anonymity. The rise of encrypted communications, cryptocurrency laundering, and dark web marketplaces has made detection harder and enforcement slower.",
		questions: [
			"Can international policing keep pace with criminals who innovate faster than law enforcement evolves?",
			"Are existing extradition treaties fit for a digital age?",
			"Who regulates cryptocurrency flows that finance global crime?",
			"Can AI-driven surveillance strengthen enforcement without eroding civil liberties?"
		]
	},
	{
		slug: "brics",
		number: "09",
		acronym: "BRICS",
		name: "BRICS",
		fullName: "BRICS",
		agenda: "BRICS by BRICS: Building the Other World",
		delegates: 25,
		summary: "BRICS now represents nearly half the world’s population and over 40 per cent of global GDP. Its recent expansion has amplified its influence on energy, infrastructure, and trade, offering an alternative to the US-dominated global order. For many members, the challenge is securing growth without being constrained by Washington’s rules.",
		questions: [
			"How can BRICS chart an independent energy strategy that reduces reliance on US-controlled financial mechanisms?",
			"What role should BRICS play in setting global standards and offering alternatives to the US-centric system?",
			"What lessons can BRICS offer other emerging economies in shaping a new world order?"
		]
	}
];
function getCommittee(slug) {
	return COMMITTEES.find((c) => c.slug === slug);
}
//#endregion
export { getCommittee as n, COMMITTEES as t };
