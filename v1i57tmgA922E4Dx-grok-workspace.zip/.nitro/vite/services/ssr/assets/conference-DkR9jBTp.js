//#region src/data/conference.ts
var SITE_NAME = "Ryan INMUN 2026";
var SITE_TAGLINE = "Indian Model United Nations";
var SITE_DESCRIPTION = "Ryan INMUN 2026 — the 24th edition of India's longest-running Model United Nations. 31 August – 2 September 2026 at SCOPE Complex, New Delhi.";
var CONFERENCE = {
	edition: 24,
	editionLabel: "24th Edition",
	established: 2001,
	dates: "31 August – 2 September 2026",
	datesShort: "31 Aug – 2 Sep 2026",
	venue: "SCOPE Complex, New Delhi",
	venueShort: "SCOPE Complex",
	city: "New Delhi",
	host: "Ryan International Group of Schools",
	foundation: "Ryan Foundation",
	theme: "Dialogue on Democracy",
	summit: "Ryan Leadership Summit",
	summitVenue: "Kedarnath Sahni Auditorium, New Delhi",
	feeNcr: "₹6,750",
	feeNcrNote: "Delhi-NCR schools, per delegate",
	payee: "Ryan Foundation, payable at New Delhi"
};
var STATS = [
	{
		value: "24th",
		label: "Edition"
	},
	{
		value: "1,000+",
		label: "Delegates"
	},
	{
		value: "100+",
		label: "Schools"
	},
	{
		value: "9",
		label: "Committees"
	},
	{
		value: "2001",
		label: "Established"
	}
];
var DATES = [
	{
		date: "15 June",
		title: "Committee preference deadline",
		detail: "Background guides sent after preferences are received."
	},
	{
		date: "1 August",
		title: "Registration and payment close",
		detail: "Submit fees with the registration form. No late entries."
	},
	{
		date: "15 August",
		title: "My Country 2026 video due",
		detail: "Upload the four-minute news report to YouTube and share the link."
	},
	{
		date: "20 August",
		title: "Travel plan deadline",
		detail: "Required for outstation teams travelling to New Delhi."
	},
	{
		date: "25 August",
		title: "Position papers due",
		detail: "Maximum two pages. Committee and country only — no name or school."
	},
	{
		date: "31 Aug – 2 Sep",
		title: "Ryan INMUN 2026 conference",
		detail: "Committee sessions at SCOPE Complex, New Delhi."
	}
];
var FORMS = [
	{
		label: "School Registration Form",
		href: "https://forms.gle/Vyj6XdBR8oVy9Gi5A",
		hint: "Submitted by the school coordinator."
	},
	{
		label: "Delegate Information Form",
		href: "https://forms.gle/HfFTYaSBraqhqtE4A",
		hint: "One form per participating student."
	},
	{
		label: "Travel Plan",
		href: "https://forms.gle/K9CXXXiT6idoKiQ67",
		hint: "Required for outstation delegations."
	},
	{
		label: "Submit Position Paper",
		href: "https://forms.gle/ie95HZNoVsu9cKUY7",
		hint: "Due 25 August. Max two pages."
	}
];
var TRAINING_FORM = "https://forms.gle/rKPKg1oxisKdSiSA6";
var COUNTRY_MATRIX = "https://docs.google.com/spreadsheets/d/13-sy3HF8qCwx8BICGP51KoahCrrOFM_s/edit?usp=sharing";
var RESOURCE_DRIVE = "https://drive.google.com/drive/folders/1ykXvqHnOz-4OLPGDjKfcD9-W6kXGh99A?usp=sharing";
var PHOTO_ALBUMS = [
	{
		label: "Day 1 photographs",
		href: "https://www.facebook.com/media/set/?set=a.10236711106971288&type=3"
	},
	{
		label: "Day 2 photographs",
		href: "https://www.facebook.com/media/set/?set=a.10236735148132302&type=3"
	},
	{
		label: "Leadership Summit photographs",
		href: "https://www.facebook.com/media/set/?set=a.10236736006793768&type=3"
	}
];
var CONTACTS = [{
	region: "West, South, Central & UAE",
	name: "Ms. Hemanshi Dedhia",
	role: "Head of Ryan MUN Clubs",
	email: "hemanshi.dedhia@ryangroup.org"
}, {
	region: "North Region",
	name: "Ms. Varsha Guha",
	role: "INMUN Coordinator",
	email: "inmun@ryangroup.org"
}];
var NAV = [
	{
		to: "/about",
		label: "About"
	},
	{
		to: "/committees",
		label: "Committees"
	},
	{
		to: "/leadership",
		label: "Leadership"
	},
	{
		to: "/participate",
		label: "Participate"
	},
	{
		to: "/competitions",
		label: "Competitions"
	},
	{
		to: "/awards",
		label: "Awards"
	},
	{
		to: "/resources",
		label: "Resources"
	}
];
var FOOTER_NAV = [
	{
		to: "/about",
		label: "About"
	},
	{
		to: "/committees",
		label: "Committees"
	},
	{
		to: "/leadership",
		label: "Leadership"
	},
	{
		to: "/participate",
		label: "Participate"
	},
	{
		to: "/competitions",
		label: "Competitions"
	},
	{
		to: "/awards",
		label: "Awards"
	},
	{
		to: "/resources",
		label: "Resources"
	},
	{
		to: "/press",
		label: "World Press"
	}
];
//#endregion
export { FOOTER_NAV as a, PHOTO_ALBUMS as c, SITE_NAME as d, SITE_TAGLINE as f, DATES as i, RESOURCE_DRIVE as l, TRAINING_FORM as m, CONTACTS as n, FORMS as o, STATS as p, COUNTRY_MATRIX as r, NAV as s, CONFERENCE as t, SITE_DESCRIPTION as u };
