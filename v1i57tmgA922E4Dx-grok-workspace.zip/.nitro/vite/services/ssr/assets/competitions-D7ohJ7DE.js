import { d as SITE_NAME } from "./conference-DkR9jBTp.js";
import { r as Button } from "./router-DCuuzYYV.js";
import { t as PageHero } from "./page-hero-Boob4Mvt.js";
import { Link } from "@tanstack/react-router";
import { jsx, jsxs } from "react/jsx-runtime";
//#region src/routes/competitions.tsx?tsr-split=component
function CompetitionsPage() {
	return /* @__PURE__ */ jsxs("main", { children: [/* @__PURE__ */ jsx(PageHero, {
		eyebrow: "Competitions",
		title: "My Country 2026",
		lede: "Digital news reportage. Each delegation creates a four-minute self-made news report on the significant developments in their assigned country."
	}), /* @__PURE__ */ jsxs("section", {
		className: "site-container grid gap-10 py-16 lg:grid-cols-[1.2fr_0.8fr] md:py-20",
		children: [/* @__PURE__ */ jsxs("div", { children: [
			/* @__PURE__ */ jsx("h2", {
				className: "display text-3xl text-navy",
				children: "The brief"
			}),
			/* @__PURE__ */ jsx("p", {
				className: "mt-4 max-w-prose text-muted",
				children: "Your video should provide a captivating overview of your country and summarise recent events across politics, economy, society, technology, law, and environment."
			}),
			/* @__PURE__ */ jsxs("ul", {
				className: "mt-6 grid gap-3 text-sm text-muted",
				children: [
					/* @__PURE__ */ jsx("li", {
						className: "card-surface p-5",
						children: "Length: 4 minutes."
					}),
					/* @__PURE__ */ jsx("li", {
						className: "card-surface p-5",
						children: "Upload to YouTube and share the link by 15 August."
					}),
					/* @__PURE__ */ jsxs("li", {
						className: "card-surface p-5",
						children: [
							"Top ten videos are awarded during the closing ceremony of ",
							SITE_NAME,
							"."
						]
					})
				]
			})
		] }), /* @__PURE__ */ jsxs("aside", {
			className: "card-surface self-start p-7",
			children: [
				/* @__PURE__ */ jsx("p", {
					className: "text-xs uppercase tracking-[0.16em] text-muted",
					children: "Also recognised"
				}),
				/* @__PURE__ */ jsx("h3", {
					className: "display mt-3 text-2xl text-navy",
					children: "Conference awards"
				}),
				/* @__PURE__ */ jsx("p", {
					className: "mt-3 text-sm text-muted",
					children: "Best Delegate by committee, Best Delegation, World Press awards, and My Country 2026."
				}),
				/* @__PURE__ */ jsx(Button, {
					asChild: true,
					className: "mt-6",
					variant: "outline",
					children: /* @__PURE__ */ jsx(Link, {
						to: "/awards",
						children: "See the awards"
					})
				})
			]
		})]
	})] });
}
//#endregion
export { CompetitionsPage as component };
