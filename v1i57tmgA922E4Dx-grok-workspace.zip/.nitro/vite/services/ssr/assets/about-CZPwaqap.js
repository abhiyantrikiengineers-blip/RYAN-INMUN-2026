import { d as SITE_NAME, t as CONFERENCE } from "./conference-DkR9jBTp.js";
import { r as Button } from "./router-DCuuzYYV.js";
import { t as PageHero } from "./page-hero-Boob4Mvt.js";
import { t as Reveal } from "./reveal-DrYYkon_.js";
import { Link } from "@tanstack/react-router";
import { jsx, jsxs } from "react/jsx-runtime";
//#region src/routes/about.tsx?tsr-split=component
function AboutPage() {
	return /* @__PURE__ */ jsxs("main", { children: [
		/* @__PURE__ */ jsx(PageHero, {
			eyebrow: "About",
			title: "India’s longest-running Model United Nations.",
			lede: `${SITE_NAME} is the 24th edition of INMUN, established in 2001 by the Ryan International Group. For over two decades it has been the proving ground for young diplomats.`
		}),
		/* @__PURE__ */ jsxs("section", {
			className: "site-container grid gap-12 py-16 md:grid-cols-[1fr_1fr] md:py-24",
			children: [/* @__PURE__ */ jsxs(Reveal, { children: [
				/* @__PURE__ */ jsx("h2", {
					className: "display text-3xl text-navy md:text-4xl",
					children: "The conference"
				}),
				/* @__PURE__ */ jsx("p", {
					className: "mt-4 text-muted",
					children: "More than 1,000 student delegates from over 100 schools across 25 Indian cities and the UAE gather in New Delhi. Over three days they take on the roles of diplomats, debating global issues, negotiating positions, and working towards resolutions."
				}),
				/* @__PURE__ */ jsxs("p", {
					className: "mt-4 text-muted",
					children: [
						"The conference culminates in the ",
						CONFERENCE.summit,
						" at the",
						" ",
						CONFERENCE.summitVenue,
						", held under the theme “",
						CONFERENCE.theme,
						"”."
					]
				})
			] }), /* @__PURE__ */ jsx(Reveal, {
				delay: 80,
				children: /* @__PURE__ */ jsxs("blockquote", {
					className: "card-surface p-8",
					children: [/* @__PURE__ */ jsx("p", {
						className: "font-display text-2xl leading-snug text-navy",
						children: "“The students who represent nations at INMUN today will represent India tomorrow. Across twenty-four editions, this conference has been their proving ground, and its alumni today serve the nation as judges, diplomats, and IAS and IPS officers.”"
					}), /* @__PURE__ */ jsxs("footer", {
						className: "mt-6 text-sm text-muted",
						children: ["Dr. Grace Pinto", /* @__PURE__ */ jsx("span", {
							className: "mt-1 block uppercase tracking-[0.14em]",
							children: "Managing Director · Ryan International Group"
						})]
					})]
				})
			})]
		}),
		/* @__PURE__ */ jsx("section", {
			className: "bg-cream py-16 md:py-20",
			children: /* @__PURE__ */ jsxs("div", {
				className: "site-container",
				children: [
					/* @__PURE__ */ jsx("h2", {
						className: "display text-3xl text-navy",
						children: "At a glance"
					}),
					/* @__PURE__ */ jsx("dl", {
						className: "mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4",
						children: [
							["Edition", CONFERENCE.editionLabel],
							["Dates", CONFERENCE.dates],
							["Venue", CONFERENCE.venue],
							["Host", CONFERENCE.host]
						].map(([k, v]) => /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("dt", {
							className: "text-xs uppercase tracking-[0.16em] text-muted",
							children: k
						}), /* @__PURE__ */ jsx("dd", {
							className: "mt-2 font-medium text-navy",
							children: v
						})] }, k))
					}),
					/* @__PURE__ */ jsx(Button, {
						asChild: true,
						className: "mt-10",
						children: /* @__PURE__ */ jsxs(Link, {
							to: "/participate",
							children: ["Participate in ", SITE_NAME]
						})
					})
				]
			})
		})
	] });
}
//#endregion
export { AboutPage as component };
