import { t as cn } from "./utils-C_uf36nf.js";
import { jsx, jsxs } from "react/jsx-runtime";
//#region src/components/page-hero.tsx
function PageHero({ eyebrow, title, lede, meta, children, dense = false }) {
	return /* @__PURE__ */ jsxs("header", {
		className: cn("relative overflow-hidden bg-navy text-cream", dense ? "pt-16 pb-14 md:pt-20 md:pb-16" : "pt-16 pb-16 md:pt-20 md:pb-20"),
		children: [/* @__PURE__ */ jsxs("div", {
			className: "pointer-events-none absolute inset-0 opacity-40",
			"aria-hidden": "true",
			children: [/* @__PURE__ */ jsx("div", { className: "absolute -right-24 top-[-20%] h-[28rem] w-[28rem] rounded-full border border-cream/10" }), /* @__PURE__ */ jsx("div", { className: "absolute -right-8 top-[8%] h-[18rem] w-[18rem] rounded-full border border-cream/10" })]
		}), /* @__PURE__ */ jsxs("div", {
			className: "site-container relative",
			children: [
				/* @__PURE__ */ jsx("p", {
					className: "eyebrow text-accent-soft",
					children: eyebrow
				}),
				/* @__PURE__ */ jsx("h1", {
					className: "display mt-5 max-w-4xl text-5xl text-cream md:text-6xl lg:text-7xl",
					children: title
				}),
				lede ? /* @__PURE__ */ jsx("p", {
					className: "prose-narrow mt-5 text-base text-on-navy-muted md:text-lg",
					children: lede
				}) : null,
				meta ? /* @__PURE__ */ jsx("div", {
					className: "mt-6 text-sm text-on-navy-muted",
					children: meta
				}) : null,
				children
			]
		})]
	});
}
//#endregion
export { PageHero as t };
