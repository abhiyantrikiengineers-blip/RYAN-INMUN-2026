import { t as COMMITTEES } from "./committees-B9-PNPbg.js";
import { t as PageHero } from "./page-hero-Boob4Mvt.js";
import { t as CommitteeCard } from "./committee-card-BU4dftiS.js";
import { jsx, jsxs } from "react/jsx-runtime";
//#region src/routes/committees/index.tsx?tsr-split=component
function CommitteesPage() {
	return /* @__PURE__ */ jsxs("main", { children: [/* @__PURE__ */ jsx(PageHero, {
		eyebrow: "Committees",
		title: "Nine committees. Nine global challenges.",
		lede: "Choose your room, read the agenda, and come prepared. Background guides follow committee preference."
	}), /* @__PURE__ */ jsx("section", {
		className: "site-container grid gap-5 py-14 sm:grid-cols-2 lg:grid-cols-3 md:py-20",
		children: COMMITTEES.map((committee, index) => /* @__PURE__ */ jsx(CommitteeCard, {
			committee,
			index
		}, committee.slug))
	})] });
}
//#endregion
export { CommitteesPage as component };
