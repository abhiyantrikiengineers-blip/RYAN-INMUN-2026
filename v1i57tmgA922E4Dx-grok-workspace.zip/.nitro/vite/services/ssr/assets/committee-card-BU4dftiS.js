import { t as cn } from "./utils-C_uf36nf.js";
import { Link } from "@tanstack/react-router";
import { jsx, jsxs } from "react/jsx-runtime";
import { ArrowUpRight } from "lucide-react";
//#region src/components/committee-card.tsx
function CommitteeCard({ committee, index = 0 }) {
	return /* @__PURE__ */ jsxs(Link, {
		to: "/committees/$slug",
		params: { slug: committee.slug },
		className: cn("group card-surface relative flex h-full flex-col p-6 transition-[transform,box-shadow] duration-200", "hover:-translate-y-1 hover:shadow-[var(--shadow-lift)]"),
		style: { transitionDelay: `${Math.min(index, 6) * 40}ms` },
		children: [
			/* @__PURE__ */ jsxs("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ jsx("span", {
					className: "font-display text-2xl text-accent",
					children: committee.number
				}), /* @__PURE__ */ jsxs("span", {
					className: "rounded-full border border-line px-2.5 py-1 text-[0.65rem] font-semibold uppercase tracking-[0.14em] text-muted",
					children: [committee.delegates, " delegates"]
				})]
			}),
			/* @__PURE__ */ jsx("h3", {
				className: "mt-6 font-display text-2xl leading-tight text-navy",
				children: committee.name
			}),
			/* @__PURE__ */ jsx("p", {
				className: "mt-1 text-xs font-semibold uppercase tracking-[0.16em] text-muted",
				children: committee.acronym
			}),
			/* @__PURE__ */ jsx("p", {
				className: "mt-4 flex-1 text-sm leading-relaxed text-muted",
				children: committee.agenda
			}),
			/* @__PURE__ */ jsxs("span", {
				className: "mt-6 inline-flex items-center gap-1 text-sm font-medium text-navy",
				children: ["Open committee", /* @__PURE__ */ jsx(ArrowUpRight, { className: "size-4 transition-transform duration-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" })]
			})
		]
	});
}
//#endregion
export { CommitteeCard as t };
