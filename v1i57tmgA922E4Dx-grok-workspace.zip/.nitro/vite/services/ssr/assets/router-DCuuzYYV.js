import { a as FOOTER_NAV, d as SITE_NAME, f as SITE_TAGLINE, n as CONTACTS, s as NAV, t as CONFERENCE, u as SITE_DESCRIPTION } from "./conference-DkR9jBTp.js";
import { t as cn } from "./utils-C_uf36nf.js";
import { n as getCommittee, t as COMMITTEES } from "./committees-B9-PNPbg.js";
import { i as chairsFor, n as SECRETARY_GENERAL, r as WORLD_PRESS_TEAM, t as EXECUTIVE_BOARD } from "./leadership-C3FxZGVA.js";
import { useEffect, useMemo, useState } from "react";
import { HeadContent, Link, Outlet, Scripts, createFileRoute, createRootRoute, createRouter, lazyRouteComponent, notFound, useNavigate, useRouter, useRouterState } from "@tanstack/react-router";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { Menu, Search, TriangleAlert, X } from "lucide-react";
import { Slot } from "@radix-ui/react-slot";
import { cva } from "class-variance-authority";
import { z } from "zod";
//#region \0rolldown/runtime.js
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
//#endregion
//#region src/lib/error-component.tsx
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ jsxs("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ jsx("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ jsx(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ jsx("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ jsx("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
//#endregion
//#region src/components/ui/button.tsx
var buttonVariants = cva("inline-flex items-center justify-center gap-2 rounded-md font-medium transition-[transform,background-color,color,border-color,opacity] duration-200 ease-[cubic-bezier(0.22,1,0.36,1)] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent disabled:pointer-events-none disabled:opacity-50 active:scale-[0.98]", {
	variants: {
		variant: {
			primary: "bg-ink text-cream hover:bg-navy",
			invert: "bg-cream text-navy hover:bg-paper",
			outline: "border border-line bg-transparent text-ink hover:border-ink hover:bg-cream",
			ghost: "bg-transparent text-cream/90 hover:bg-white/8 hover:text-cream",
			accent: "bg-accent text-cream hover:bg-navy-3"
		},
		size: {
			sm: "h-10 px-4 text-sm",
			md: "h-11 px-5 text-sm",
			lg: "h-12 px-6 text-[0.95rem]"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ jsx(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
//#endregion
//#region src/components/not-found.tsx
function NotFound() {
	return /* @__PURE__ */ jsxs("main", {
		className: "flex min-h-[70vh] flex-col items-center justify-center px-6 text-center",
		children: [
			/* @__PURE__ */ jsx("p", {
				className: "eyebrow",
				children: "Page not found"
			}),
			/* @__PURE__ */ jsx("h1", {
				className: "display mt-4 text-5xl text-navy md:text-6xl",
				children: "This corridor is empty."
			}),
			/* @__PURE__ */ jsxs("p", {
				className: "prose-narrow mt-4 text-muted",
				children: [
					"The page you requested is not part of ",
					SITE_NAME,
					". Return to the conference home, or open the committees."
				]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "mt-8 flex flex-wrap justify-center gap-3",
				children: [/* @__PURE__ */ jsx(Button, {
					asChild: true,
					children: /* @__PURE__ */ jsx(Link, {
						to: "/",
						children: "Back to home"
					})
				}), /* @__PURE__ */ jsx(Button, {
					asChild: true,
					variant: "outline",
					children: /* @__PURE__ */ jsx(Link, {
						to: "/committees",
						children: "View committees"
					})
				})]
			})
		]
	});
}
//#endregion
//#region src/lib/auth/provider.tsx
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ jsx(Fragment, { children });
}
//#endregion
//#region src/lib/app-data/types.ts
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
//#endregion
//#region src/lib/preview-embedder-origin.ts
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
//#endregion
//#region src/lib/preview-host-bridge.ts
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = z.object({
	channel: z.literal(PREVIEW_BRIDGE_CHANNEL),
	version: z.number().int().positive(),
	type: z.string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: z.literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: z.literal("navigate"),
	path: z.string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: z.literal("history"),
	delta: z.union([z.literal(-1), z.literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: z.literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
//#endregion
//#region src/components/preview-host-bridge.tsx
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	useEffect(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
//#endregion
//#region src/components/wordmark.tsx
function Wordmark({ invert = false, compact = false }) {
	return /* @__PURE__ */ jsxs(Link, {
		to: "/",
		"aria-label": `${SITE_NAME} home`,
		className: "group flex items-center gap-3",
		children: [/* @__PURE__ */ jsx("span", {
			className: cn("grid size-9 place-items-center rounded-full border text-[0.65rem] font-semibold tracking-[0.12em]", invert ? "border-cream/25 text-cream" : "border-navy/20 text-navy"),
			"aria-hidden": "true",
			children: "24"
		}), /* @__PURE__ */ jsxs("span", {
			className: "flex flex-col leading-none",
			children: [/* @__PURE__ */ jsx("span", {
				className: cn("font-display text-[1.2rem] font-semibold tracking-tight", invert ? "text-cream" : "text-navy"),
				children: "Ryan INMUN"
			}), !compact ? /* @__PURE__ */ jsx("span", {
				className: cn("mt-1 text-[0.62rem] font-medium uppercase tracking-[0.22em]", invert ? "text-on-navy-muted" : "text-muted"),
				children: "2026"
			}) : /* @__PURE__ */ jsx("span", {
				className: cn("mt-1 text-[0.62rem] font-medium uppercase tracking-[0.22em]", invert ? "text-on-navy-muted" : "text-muted"),
				children: "2026"
			})]
		})]
	});
}
//#endregion
//#region src/components/site-search.tsx
function buildIndex() {
	const pages = [
		{
			label: "Home",
			hint: SITE_NAME,
			to: "/"
		},
		...NAV.map((item) => ({
			label: item.label,
			hint: "Page",
			to: item.to
		})),
		{
			label: "World Press",
			hint: "Page",
			to: "/press"
		}
	];
	const committees = COMMITTEES.map((c) => ({
		label: c.fullName,
		hint: c.agenda,
		to: `/committees/${c.slug}`
	}));
	const people = [
		SECRETARY_GENERAL,
		...EXECUTIVE_BOARD,
		...WORLD_PRESS_TEAM
	].map((person) => ({
		label: person.name,
		hint: `${person.role} · ${person.school}`,
		to: person.committeeSlug ? `/committees/${person.committeeSlug}` : "/leadership"
	}));
	return [
		...pages,
		...committees,
		...people
	];
}
function SiteSearch() {
	const [open, setOpen] = useState(false);
	const [query, setQuery] = useState("");
	const navigate = useNavigate();
	const index = useMemo(buildIndex, []);
	const hits = useMemo(() => {
		const q = query.trim().toLowerCase();
		if (!q) return index.slice(0, 8);
		return index.filter((hit) => hit.label.toLowerCase().includes(q) || hit.hint.toLowerCase().includes(q)).slice(0, 10);
	}, [index, query]);
	useEffect(() => {
		const onKey = (event) => {
			if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
				event.preventDefault();
				setOpen(true);
			}
			if (event.key === "Escape") setOpen(false);
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, []);
	useEffect(() => {
		if (!open) setQuery("");
	}, [open]);
	return /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsxs("button", {
		type: "button",
		onClick: () => setOpen(true),
		className: "inline-flex h-10 items-center gap-2 rounded-full border border-cream/15 bg-white/5 px-3 text-sm text-on-navy-muted transition-colors hover:border-cream/30 hover:text-cream",
		"aria-label": `Search ${SITE_NAME}`,
		children: [/* @__PURE__ */ jsx(Search, {
			className: "size-4",
			strokeWidth: 1.75
		}), /* @__PURE__ */ jsx("span", {
			className: "hidden md:inline",
			children: "Search"
		})]
	}), open ? /* @__PURE__ */ jsx("div", {
		className: "fixed inset-0 z-80 flex items-start justify-center bg-navy/70 px-4 pt-[12vh] backdrop-blur-sm",
		role: "dialog",
		"aria-modal": "true",
		"aria-label": `Search ${SITE_NAME}`,
		onClick: () => setOpen(false),
		children: /* @__PURE__ */ jsxs("div", {
			className: "w-full max-w-xl overflow-hidden rounded-2xl border border-line bg-cream shadow-[0_24px_80px_-24px_rgba(8,20,34,0.55)]",
			onClick: (e) => e.stopPropagation(),
			children: [/* @__PURE__ */ jsxs("div", {
				className: "flex items-center gap-3 border-b border-line px-4",
				children: [
					/* @__PURE__ */ jsx(Search, { className: "size-4 text-muted" }),
					/* @__PURE__ */ jsx("input", {
						autoFocus: true,
						value: query,
						onChange: (e) => setQuery(e.target.value),
						placeholder: "Committees, people, pages…",
						className: "h-14 flex-1 bg-transparent text-base text-ink outline-none placeholder:text-muted"
					}),
					/* @__PURE__ */ jsx("button", {
						type: "button",
						onClick: () => setOpen(false),
						className: "grid size-9 place-items-center rounded-full text-muted hover:bg-paper-2 hover:text-ink",
						"aria-label": "Close search",
						children: /* @__PURE__ */ jsx(X, { className: "size-4" })
					})
				]
			}), /* @__PURE__ */ jsx("ul", {
				className: "max-h-[50vh] overflow-y-auto p-2",
				children: hits.length === 0 ? /* @__PURE__ */ jsxs("li", {
					className: "px-3 py-8 text-center text-sm text-muted",
					children: [
						"No matches in ",
						SITE_NAME,
						"."
					]
				}) : hits.map((hit) => /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsxs(Link, {
					to: hit.to,
					onClick: () => {
						setOpen(false);
						navigate({ to: hit.to });
					},
					className: "block rounded-xl px-3 py-3 transition-colors hover:bg-paper-2",
					children: [/* @__PURE__ */ jsx("div", {
						className: "text-sm font-medium text-ink",
						children: hit.label
					}), /* @__PURE__ */ jsx("div", {
						className: "mt-0.5 line-clamp-1 text-xs text-muted",
						children: hit.hint
					})]
				}) }, `${hit.to}-${hit.label}`))
			})]
		})
	}) : null] });
}
//#endregion
//#region src/components/site-header.tsx
function SiteHeader() {
	const [open, setOpen] = useState(false);
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	return /* @__PURE__ */ jsxs("header", {
		className: "sticky top-0 z-50 border-b border-cream/10 bg-navy/95 backdrop-blur-md",
		children: [/* @__PURE__ */ jsxs("div", {
			className: "site-container flex h-[4.25rem] items-center justify-between gap-4",
			children: [
				/* @__PURE__ */ jsx(Wordmark, { invert: true }),
				/* @__PURE__ */ jsx("nav", {
					className: "hidden items-center gap-6 lg:flex",
					"aria-label": `${SITE_NAME} primary`,
					children: NAV.map((item) => {
						const active = pathname === item.to || pathname.startsWith(`${item.to}/`);
						return /* @__PURE__ */ jsx(Link, {
							to: item.to,
							className: cn("nav-underline text-[0.8rem] font-medium uppercase tracking-[0.14em] text-cream/80 hover:text-cream", active && "is-active text-cream"),
							children: item.label
						}, item.to);
					})
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ jsx(SiteSearch, {}),
						/* @__PURE__ */ jsx(Button, {
							asChild: true,
							size: "sm",
							variant: "invert",
							className: "hidden sm:inline-flex",
							children: /* @__PURE__ */ jsx(Link, {
								to: "/participate",
								children: "Participate"
							})
						}),
						/* @__PURE__ */ jsx("button", {
							type: "button",
							className: "grid size-10 place-items-center rounded-full border border-cream/15 text-cream lg:hidden",
							"aria-label": open ? "Close menu" : "Open menu",
							"aria-expanded": open,
							onClick: () => setOpen((v) => !v),
							children: open ? /* @__PURE__ */ jsx(X, { className: "size-5" }) : /* @__PURE__ */ jsx(Menu, { className: "size-5" })
						})
					]
				})
			]
		}), open ? /* @__PURE__ */ jsx("div", {
			className: "border-t border-cream/10 bg-navy px-4 py-5 lg:hidden",
			children: /* @__PURE__ */ jsxs("nav", {
				className: "flex flex-col gap-1",
				"aria-label": `${SITE_NAME} mobile`,
				children: [
					NAV.map((item) => /* @__PURE__ */ jsx(Link, {
						to: item.to,
						onClick: () => setOpen(false),
						className: "rounded-xl px-3 py-3 text-sm font-medium text-cream hover:bg-white/10",
						children: item.label
					}, item.to)),
					/* @__PURE__ */ jsx(Link, {
						to: "/press",
						onClick: () => setOpen(false),
						className: "rounded-xl px-3 py-3 text-sm font-medium text-cream hover:bg-white/10",
						children: "World Press"
					}),
					/* @__PURE__ */ jsx(Button, {
						asChild: true,
						className: "mt-2",
						variant: "invert",
						children: /* @__PURE__ */ jsx(Link, {
							to: "/participate",
							onClick: () => setOpen(false),
							children: "Participate"
						})
					})
				]
			})
		}) : null]
	});
}
//#endregion
//#region src/components/site-footer.tsx
function SiteFooter() {
	return /* @__PURE__ */ jsxs("footer", {
		className: "bg-navy text-cream",
		children: [/* @__PURE__ */ jsxs("div", {
			className: "site-container grid gap-12 py-16 md:grid-cols-[1.4fr_1fr_1fr]",
			children: [
				/* @__PURE__ */ jsxs("div", { children: [
					/* @__PURE__ */ jsx(Wordmark, { invert: true }),
					/* @__PURE__ */ jsxs("p", {
						className: "mt-5 max-w-sm text-sm leading-relaxed text-on-navy-muted",
						children: [
							SITE_TAGLINE,
							". India’s longest-running Model United Nations, hosted by the ",
							CONFERENCE.host,
							"."
						]
					}),
					/* @__PURE__ */ jsxs("p", {
						className: "mt-4 text-sm text-cream/90",
						children: [
							CONFERENCE.datesShort,
							/* @__PURE__ */ jsx("span", {
								className: "mx-2 text-cream/30",
								children: "·"
							}),
							CONFERENCE.venue
						]
					})
				] }),
				/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("p", {
					className: "text-[0.7rem] font-semibold uppercase tracking-[0.18em] text-on-navy-muted",
					children: "Explore"
				}), /* @__PURE__ */ jsx("ul", {
					className: "mt-4 grid gap-2",
					children: FOOTER_NAV.map((item) => /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(Link, {
						to: item.to,
						className: "text-sm text-cream/85 transition-colors hover:text-cream",
						children: item.label
					}) }, item.to))
				})] }),
				/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("p", {
					className: "text-[0.7rem] font-semibold uppercase tracking-[0.18em] text-on-navy-muted",
					children: "Coordinators"
				}), /* @__PURE__ */ jsx("ul", {
					className: "mt-4 grid gap-5",
					children: CONTACTS.map((person) => /* @__PURE__ */ jsxs("li", { children: [
						/* @__PURE__ */ jsx("p", {
							className: "text-sm font-medium text-cream",
							children: person.name
						}),
						/* @__PURE__ */ jsxs("p", {
							className: "text-xs text-on-navy-muted",
							children: [
								person.role,
								" · ",
								person.region
							]
						}),
						/* @__PURE__ */ jsx("a", {
							href: `mailto:${person.email}`,
							className: "mt-1 inline-block text-sm text-accent-soft underline-offset-4 hover:underline",
							children: person.email
						})
					] }, person.email))
				})] })
			]
		}), /* @__PURE__ */ jsx("div", {
			className: "border-t border-cream/10",
			children: /* @__PURE__ */ jsxs("div", {
				className: "site-container flex flex-col gap-2 py-5 text-xs text-on-navy-muted sm:flex-row sm:items-center sm:justify-between",
				children: [/* @__PURE__ */ jsxs("p", { children: [
					"© ",
					SITE_NAME,
					". ",
					CONFERENCE.host,
					"."
				] }), /* @__PURE__ */ jsx("p", { children: "SCOPE Complex · New Delhi" })]
			})
		})]
	});
}
//#endregion
//#region src/components/site-shell.tsx
function SiteShell({ children }) {
	return /* @__PURE__ */ jsxs("div", {
		className: "flex min-h-dvh flex-col bg-paper text-ink",
		children: [
			/* @__PURE__ */ jsx(SiteHeader, {}),
			/* @__PURE__ */ jsx("div", {
				className: "flex-1",
				children
			}),
			/* @__PURE__ */ jsx(SiteFooter, {})
		]
	});
}
//#endregion
//#region src/styles.css?url
var styles_default = "/assets/styles-BMhjqeaa.css";
//#endregion
//#region src/routes/__root.tsx
var Route$10 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: SITE_NAME },
			{
				name: "description",
				content: SITE_DESCRIPTION
			},
			{
				name: "theme-color",
				content: "#081422"
			},
			{
				name: "application-name",
				content: SITE_NAME
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,500;0,600;0,700;1,500&family=Outfit:wght@400;500;600;700&display=swap"
			}
		]
	}),
	component: RootDocument
});
function RootDocument() {
	return /* @__PURE__ */ jsxs("html", {
		lang: "en",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ jsx("head", { children: /* @__PURE__ */ jsx(HeadContent, {}) }), /* @__PURE__ */ jsxs("body", { children: [
			/* @__PURE__ */ jsx(PreviewHostBridge, {}),
			/* @__PURE__ */ jsx(AuthProvider, { children: /* @__PURE__ */ jsx(SiteShell, { children: /* @__PURE__ */ jsx(Outlet, {}) }) }),
			/* @__PURE__ */ jsx(Scripts, {})
		] })]
	});
}
//#endregion
//#region src/routes/index.tsx
var $$splitComponentImporter$9 = () => import("./routes-CWKRL5DJ.js");
var Route$9 = createFileRoute("/")({
	head: () => ({ meta: [{ title: SITE_NAME }, {
		name: "description",
		content: SITE_DESCRIPTION
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
//#endregion
//#region src/routes/about.tsx
var $$splitComponentImporter$8 = () => import("./about-CZPwaqap.js");
var Route$8 = createFileRoute("/about")({
	head: () => ({ meta: [{ title: `About · ${SITE_NAME}` }, {
		name: "description",
		content: `About ${SITE_NAME}, the 24th Indian Model United Nations hosted by the Ryan International Group of Schools.`
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
//#endregion
//#region src/routes/awards.tsx
var $$splitComponentImporter$7 = () => import("./awards-_KjVzDoP.js");
var Route$7 = createFileRoute("/awards")({
	head: () => ({ meta: [{ title: `Awards · ${SITE_NAME}` }, {
		name: "description",
		content: `Awards and recognition from ${SITE_NAME} — Best Delegation, committee awards, and World Press.`
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
//#endregion
//#region src/routes/competitions.tsx
var $$splitComponentImporter$6 = () => import("./competitions-D7ohJ7DE.js");
var Route$6 = createFileRoute("/competitions")({
	head: () => ({ meta: [{ title: `Competitions · ${SITE_NAME}` }, {
		name: "description",
		content: `My Country 2026 digital news reportage competition at ${SITE_NAME}.`
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
//#endregion
//#region src/routes/leadership.tsx
var $$splitComponentImporter$5 = () => import("./leadership-qvjqZs48.js");
var Route$5 = createFileRoute("/leadership")({
	head: () => ({ meta: [{ title: `Leadership · ${SITE_NAME}` }, {
		name: "description",
		content: `Secretary-General, Executive Board, and World Press leadership for ${SITE_NAME}.`
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
//#endregion
//#region src/routes/participate.tsx
var $$splitComponentImporter$4 = () => import("./participate-DDG7HkiD.js");
var Route$4 = createFileRoute("/participate")({
	head: () => ({ meta: [{ title: `Participate · ${SITE_NAME}` }, {
		name: "description",
		content: `Fees, dates, registration forms, country allocation, and position papers for ${SITE_NAME}.`
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
//#endregion
//#region src/routes/press.tsx
var $$splitComponentImporter$3 = () => import("./press-CwSEb_Wy.js");
var Route$3 = createFileRoute("/press")({
	head: () => ({ meta: [{ title: `World Press · ${SITE_NAME}` }, {
		name: "description",
		content: `World Press desk of ${SITE_NAME} — editors, photographers, and caricaturists.`
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
//#endregion
//#region src/routes/resources.tsx
var $$splitComponentImporter$2 = () => import("./resources-C-wbSpCx.js");
var Route$2 = createFileRoute("/resources")({
	head: () => ({ meta: [{ title: `Resources · ${SITE_NAME}` }, {
		name: "description",
		content: `Delegate handbook, forms, country matrix, training, and photograph albums for ${SITE_NAME}.`
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
//#endregion
//#region src/routes/committees/index.tsx
var $$splitComponentImporter$1 = () => import("./committees-xwmfFCZY.js");
var Route$1 = createFileRoute("/committees/")({
	head: () => ({ meta: [{ title: `Committees · ${SITE_NAME}` }, {
		name: "description",
		content: `Nine committees of ${SITE_NAME} — agendas, sizes, and research questions.`
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
//#endregion
//#region src/routes/committees/$slug.tsx
var $$splitComponentImporter = () => import("./_slug-DgLam9Y6.js");
var Route = createFileRoute("/committees/$slug")({
	loader: ({ params }) => {
		const committee = getCommittee(params.slug);
		if (!committee) throw notFound();
		return {
			committee,
			chairs: chairsFor(committee.slug)
		};
	},
	head: ({ loaderData }) => ({ meta: [{ title: loaderData ? `${loaderData.committee.fullName} · ${SITE_NAME}` : SITE_NAME }, {
		name: "description",
		content: loaderData ? `${loaderData.committee.fullName} at ${SITE_NAME}: ${loaderData.committee.agenda}` : SITE_NAME
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
//#region src/routeTree.gen.ts
var IndexRoute = Route$9.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$10
});
var AboutRoute = Route$8.update({
	id: "/about",
	path: "/about",
	getParentRoute: () => Route$10
});
var AwardsRoute = Route$7.update({
	id: "/awards",
	path: "/awards",
	getParentRoute: () => Route$10
});
var CompetitionsRoute = Route$6.update({
	id: "/competitions",
	path: "/competitions",
	getParentRoute: () => Route$10
});
var LeadershipRoute = Route$5.update({
	id: "/leadership",
	path: "/leadership",
	getParentRoute: () => Route$10
});
var ParticipateRoute = Route$4.update({
	id: "/participate",
	path: "/participate",
	getParentRoute: () => Route$10
});
var PressRoute = Route$3.update({
	id: "/press",
	path: "/press",
	getParentRoute: () => Route$10
});
var ResourcesRoute = Route$2.update({
	id: "/resources",
	path: "/resources",
	getParentRoute: () => Route$10
});
var CommitteesIndexRoute = Route$1.update({
	id: "/committees/",
	path: "/committees/",
	getParentRoute: () => Route$10
});
var rootRouteChildren = {
	IndexRoute,
	AboutRoute,
	AwardsRoute,
	CompetitionsRoute,
	LeadershipRoute,
	ParticipateRoute,
	PressRoute,
	ResourcesRoute,
	CommitteesSlugRoute: Route.update({
		id: "/committees/$slug",
		path: "/committees/$slug",
		getParentRoute: () => Route$10
	}),
	CommitteesIndexRoute
};
var routeTree = Route$10._addFileChildren(rootRouteChildren)._addFileTypes();
//#endregion
//#region src/router.tsx
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent,
		defaultNotFoundComponent: NotFound
	});
}
//#endregion
export { getRouter, Route as n, Button as r, router_exports as t };
