import { c as PHOTO_ALBUMS, d as SITE_NAME, l as RESOURCE_DRIVE, m as TRAINING_FORM, o as FORMS, r as COUNTRY_MATRIX } from "./conference-DkR9jBTp.js";
import { t as PageHero } from "./page-hero-Boob4Mvt.js";
import { Link } from "@tanstack/react-router";
import { jsx, jsxs } from "react/jsx-runtime";
import { ArrowUpRight } from "lucide-react";
//#region src/routes/resources.tsx?tsr-split=component
var LINKS = [
	{
		label: "Country allocation matrix",
		href: COUNTRY_MATRIX,
		hint: "Assigned countries by school."
	},
	{
		label: "Background guides drive",
		href: RESOURCE_DRIVE,
		hint: "Shared preparation materials."
	},
	{
		label: "Training session form",
		href: TRAINING_FORM,
		hint: "Online training for delegates."
	},
	{
		label: "School registration",
		href: FORMS[0].href,
		hint: FORMS[0].hint
	},
	{
		label: "Delegate information",
		href: FORMS[1].href,
		hint: FORMS[1].hint
	},
	{
		label: "Travel plan",
		href: FORMS[2].href,
		hint: FORMS[2].hint
	},
	{
		label: "Position paper upload",
		href: FORMS[3].href,
		hint: FORMS[3].hint
	}
];
function ResourcesPage() {
	return /* @__PURE__ */ jsxs("main", { children: [/* @__PURE__ */ jsx(PageHero, {
		eyebrow: "Resources",
		title: "Guides, forms, and the record of the conference.",
		lede: `Everything a coordinator or delegate needs for ${SITE_NAME} — plus photographs from the three days.`
	}), /* @__PURE__ */ jsxs("section", {
		className: "site-container py-16 md:py-20",
		children: [
			/* @__PURE__ */ jsx("h2", {
				className: "display text-3xl text-navy",
				children: "Delegate materials"
			}),
			/* @__PURE__ */ jsx("div", {
				className: "mt-6 grid gap-4 md:grid-cols-2",
				children: LINKS.map((item) => /* @__PURE__ */ jsxs("a", {
					href: item.href,
					target: "_blank",
					rel: "noopener noreferrer",
					className: "card-surface flex items-start justify-between gap-4 p-6",
					children: [/* @__PURE__ */ jsxs("span", { children: [/* @__PURE__ */ jsx("span", {
						className: "block font-medium text-navy",
						children: item.label
					}), /* @__PURE__ */ jsx("span", {
						className: "mt-1 block text-sm text-muted",
						children: item.hint
					})] }), /* @__PURE__ */ jsx(ArrowUpRight, { className: "size-4 text-muted" })]
				}, item.href))
			}),
			/* @__PURE__ */ jsx("h2", {
				className: "display mt-14 text-3xl text-navy",
				children: "Photographs"
			}),
			/* @__PURE__ */ jsx("div", {
				className: "mt-6 grid gap-4 md:grid-cols-3",
				children: PHOTO_ALBUMS.map((album) => /* @__PURE__ */ jsxs("a", {
					href: album.href,
					target: "_blank",
					rel: "noopener noreferrer",
					className: "card-surface flex items-center justify-between p-6",
					children: [/* @__PURE__ */ jsx("span", {
						className: "font-medium text-navy",
						children: album.label
					}), /* @__PURE__ */ jsx(ArrowUpRight, { className: "size-4 text-muted" })]
				}, album.href))
			}),
			/* @__PURE__ */ jsxs("p", {
				className: "mt-8 text-sm text-muted",
				children: [
					"Looking for chairs? See",
					" ",
					/* @__PURE__ */ jsx(Link, {
						to: "/leadership",
						className: "text-navy underline-offset-4 hover:underline",
						children: "leadership"
					}),
					". For World Press, visit the",
					" ",
					/* @__PURE__ */ jsx(Link, {
						to: "/press",
						className: "text-navy underline-offset-4 hover:underline",
						children: "press desk"
					}),
					"."
				]
			})
		]
	})] });
}
//#endregion
export { ResourcesPage as component };
